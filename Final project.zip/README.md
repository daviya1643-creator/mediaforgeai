# MediaForge AI

A browser-based multimedia workflow platform powered by Transformers.js and ONNX Runtime.

## Adobe Premiere Pro handoff

The Export & Share screen can download a Final Cut Pro 7 XML interchange sequence for Adobe Premiere Pro. In Premiere Pro, choose **File > Import**, select the exported `.xml`, and relink any browser-uploaded source media if Premiere reports it offline. Save the imported sequence as a `.prproj` to continue editing. The XML does not embed media files.

See [Premiere Pro XML export](docs/premiere-pro-export.md) for media relinking and caption instructions.
