import { useEffect } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import WorkflowBar from './WorkflowBar';
import Dashboard from '@/components/dashboard/Dashboard';
import ScriptWriter from '@/components/scriptwriter/ScriptWriter';
import ResearchHub from '@/components/research/ResearchHub';
import MediaStudio from '@/components/media/MediaStudio';
import VideoEditor from '@/components/media/VideoEditor';
import AIAnalysis from '@/components/analysis/AIAnalysis';
import AssetManager from '@/components/assets/AssetManager';
import ExportShare from '@/components/export/ExportShare';
import Collaboration from '@/components/collaboration/Collaboration';
import { useAppStore } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import { loadFromIndexedDB } from '@/utils/persistence';
import { initKeyboardShortcuts, registerShortcut, SHORTCUTS } from '@/utils/keyboard';
import { getNextStep } from '@/utils/workflow';

function NotificationToast() {
  const { notifications, removeNotification } = useAppStore();
  const latest = notifications.slice(-3);

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {latest.map((n) => (
        <div
          key={n.id}
          className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm shadow-2xl cursor-pointer animate-slide-in
            ${n.type === 'success' ? 'bg-emerald-600 text-white' : ''}
            ${n.type === 'error' ? 'bg-red-600 text-white' : ''}
            ${n.type === 'info' ? 'bg-slate-800 text-slate-200 border border-slate-700' : ''}`}
          onClick={() => removeNotification(n.id)}
        >
          <span>{n.type === 'success' ? '✅' : n.type === 'error' ? '❌' : 'ℹ️'}</span>
          {n.message}
        </div>
      ))}
    </div>
  );
}

export default function MainLayout() {
  const { activeTab, setActiveTab, addNotification } = useAppStore();

  // Load persisted state on mount
  useEffect(() => {
    (async () => {
      const savedProjects = await loadFromIndexedDB<ReturnType<typeof useProjectStore.getState>['projects']>('projects');
      if (savedProjects && savedProjects.length > 0) {
        useProjectStore.setState({ projects: savedProjects });
        addNotification({ message: `${savedProjects.length} project(s) restored from saved session`, type: 'info' });
      }
    })();
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const cleanup = initKeyboardShortcuts();

    const unreg1 = registerShortcut(SHORTCUTS.NEXT_STEP, () => {
      const next = getNextStep(activeTab);
      if (next) {
        setActiveTab(next);
        addNotification({ message: '⏭️ Jumped to next step', type: 'info' });
      }
    });

    const unreg2 = registerShortcut('ctrl+s', (e) => {
      e.preventDefault();
      addNotification({ message: '💾 Project saved to IndexedDB', type: 'success' });
    });

    const unreg3 = registerShortcut('ctrl+b', () => {
      useAppStore.getState().toggleSidebar();
    });

    return () => {
      cleanup();
      unreg1();
      unreg2();
      unreg3();
    };
  }, [activeTab]);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'scriptwriter': return <ScriptWriter />;
      case 'research': return <ResearchHub />;
      case 'media': return <MediaStudio />;
      case 'video-editor': return <VideoEditor />;
      case 'analysis': return <AIAnalysis />;
      case 'assets': return <AssetManager />;
      case 'export': return <ExportShare />;
      case 'collaboration': return <Collaboration />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-950 text-slate-100">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header />
        <WorkflowBar />
        <main className="flex-1 overflow-y-auto bg-slate-950">
          {renderContent()}
        </main>
      </div>
      <NotificationToast />
    </div>
  );
}
