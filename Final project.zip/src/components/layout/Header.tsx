import { useAppStore } from '@/stores/appStore';
import { cn } from '@/utils/cn';
import { FiMenu, FiMoon, FiSun, FiBell, FiCpu } from 'react-icons/fi';
import BatchProcessor from './BatchProcessor';
import TemplateManager from './TemplateManager';
import AutoSaveIndicator from './AutoSaveIndicator';

export default function Header() {
  const {
    toggleSidebar,
    darkMode,
    toggleDarkMode,
    processingQueue,
    isAILoading,
    notifications,
  } = useAppStore();

  const activeTasks = processingQueue.filter((t) => t.status === 'running').length;

  return (
    <header className="flex h-14 items-center justify-between border-b border-slate-800 bg-slate-950 px-4">
      <div className="flex items-center gap-2">
        <button
          onClick={toggleSidebar}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
        >
          <FiMenu size={18} />
        </button>
        <div className="hidden items-center gap-2 text-xs text-slate-500 sm:flex">
          <span className={cn('h-1.5 w-1.5 rounded-full', isAILoading ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400')} />
          {isAILoading ? 'AI Processing...' : 'AI Ready'}
        </div>
        <AutoSaveIndicator />
      </div>

      <div className="flex items-center gap-1.5">
        <TemplateManager />
        <BatchProcessor />

        {activeTasks > 0 && (
          <div className="flex items-center gap-1 rounded-full bg-violet-600/20 px-3 py-1 text-xs text-violet-400">
            <FiCpu size={12} className="animate-pulse" />
            {activeTasks}
          </div>
        )}

        <button className="relative rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-slate-200">
          <FiBell size={18} />
          {notifications.length > 0 && (
            <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500" />
          )}
        </button>

        <button
          onClick={toggleDarkMode}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
        >
          {darkMode ? <FiSun size={18} /> : <FiMoon size={18} />}
        </button>

        <div className="ml-1 flex items-center gap-2 rounded-lg bg-slate-800 px-2.5 py-1.5">
          <div className="h-6 w-6 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-[10px] font-bold text-white">
            P
          </div>
          <span className="text-xs text-slate-300 hidden xl:block">Professor</span>
        </div>
      </div>
    </header>
  );
}
