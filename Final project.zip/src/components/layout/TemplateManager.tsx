import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import { cn } from '@/utils/cn';
import { FiLayers, FiX, FiPlay } from 'react-icons/fi';

interface Template {
  id: string;
  name: string;
  description: string;
  emoji: string;
  type: 'youtube' | 'tiktok' | 'instagram' | 'podcast' | 'tutorial' | 'music-video';
  settings: {
    resolution: string;
    aspectRatio: string;
    frameRate: number;
    format: string;
  };
  sceneStructure: string[];
}

const BUILT_IN_TEMPLATES: Template[] = [
  {
    id: 'youtube-vlog',
    name: 'YouTube Vlog',
    description: 'Standard vlog with intro, b-roll, and outro',
    emoji: '🎥',
    type: 'youtube',
    settings: { resolution: '4K', aspectRatio: '16:9', frameRate: 30, format: 'mp4' },
    sceneStructure: ['Intro Hook', 'B-Roll Montage', 'Main Content', 'Call to Action', 'Outro + Subscribe'],
  },
  {
    id: 'tiktok-viral',
    name: 'TikTok Viral',
    description: 'Fast-paced vertical content optimized for TikTok',
    emoji: '🔥',
    type: 'tiktok',
    settings: { resolution: '1080p', aspectRatio: '9:16', frameRate: 60, format: 'mp4' },
    sceneStructure: ['Hook (0-3s)', 'Pattern Interrupt', 'Main Payoff', 'Loop Ending'],
  },
  {
    id: 'instagram-reel',
    name: 'Instagram Reel',
    description: 'Polished reel with trending structure',
    emoji: '📸',
    type: 'instagram',
    settings: { resolution: '1080p', aspectRatio: '9:16', frameRate: 30, format: 'mp4' },
    sceneStructure: ['Attention Grab', 'Quick Cuts', 'Value Drop', 'Engagement Ask'],
  },
  {
    id: 'tutorial',
    name: 'Tutorial / How-To',
    description: 'Step-by-step instructional video',
    emoji: '📚',
    type: 'tutorial',
    settings: { resolution: '1080p', aspectRatio: '16:9', frameRate: 30, format: 'mp4' },
    sceneStructure: ['Problem Statement', 'What You\'ll Learn', 'Step 1-3', 'Result Demo', 'Recap + CTA'],
  },
  {
    id: 'podcast',
    name: 'Podcast Clip',
    description: 'Audiogram-style with waveform visualization',
    emoji: '🎙️',
    type: 'podcast',
    settings: { resolution: '1080p', aspectRatio: '1:1', frameRate: 30, format: 'mp4' },
    sceneStructure: ['Quote Hook', 'Speaker Intro', 'Key Insight', 'Channel Plug'],
  },
  {
    id: 'music-video',
    name: 'Music Visualizer',
    description: 'Audio-reactive visual content',
    emoji: '🎵',
    type: 'music-video',
    settings: { resolution: '4K', aspectRatio: '16:9', frameRate: 60, format: 'mp4' },
    sceneStructure: ['Title Card', 'Verse 1 Visuals', 'Chorus Impact', 'Bridge', 'Outro Fade'],
  },
];

export default function TemplateManager() {
  const { addNotification } = useAppStore();
  const { createProject } = useProjectStore();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [projectName, setProjectName] = useState('');

  const handleApplyTemplate = () => {
    if (!selectedTemplate) return;
    const name = projectName.trim() || selectedTemplate.name;

    createProject({
      name,
      description: `Created from ${selectedTemplate.name} template`,
      type: 'video',
      status: 'draft',
      scripts: selectedTemplate.sceneStructure.map((scene, i) => ({
        id: `scr_${Date.now()}_${i}`,
        content: scene,
        type: 'scene',
        order: i,
        aiGenerated: false,
      })),
      mediaAssets: [],
      timeline: [],
      settings: {
        resolution: selectedTemplate.settings.resolution as '1080p' | '4K' | '720p',
        frameRate: selectedTemplate.settings.frameRate as 24 | 30 | 60,
        format: selectedTemplate.settings.format as 'mp4',
        quality: 'high',
        aspectRatio: selectedTemplate.settings.aspectRatio as '16:9' | '9:16' | '1:1' | '4:3',
      },
    });

    addNotification({ message: `Template "${selectedTemplate.name}" applied!`, type: 'success' });
    setIsOpen(false);
    setSelectedTemplate(null);
    setProjectName('');
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-1.5 rounded-lg bg-indigo-600/10 border border-indigo-600/30 px-3 py-1.5 text-xs text-indigo-400 hover:bg-indigo-600/20 transition-all"
        title="Smart Templates"
      >
        <FiLayers size={12} />
        Templates
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setIsOpen(false)}>
          <div className="w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <FiLayers size={18} className="text-indigo-400" />
                Smart Templates
              </h3>
              <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white">
                <FiX size={18} />
              </button>
            </div>

            <p className="text-sm text-slate-400 mb-4">
              Jumpstart your project with pre-configured templates for every platform.
              Each template includes scene structure and optimal export settings.
            </p>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
              {BUILT_IN_TEMPLATES.map((template) => (
                <button
                  key={template.id}
                  onClick={() => setSelectedTemplate(template)}
                  className={cn(
                    'rounded-xl p-4 text-left transition-all border',
                    selectedTemplate?.id === template.id
                      ? 'border-indigo-500 bg-indigo-600/10 ring-1 ring-indigo-500/50'
                      : 'border-slate-800 bg-slate-800/50 hover:border-slate-700'
                  )}
                >
                  <span className="text-2xl">{template.emoji}</span>
                  <p className="text-sm font-medium text-white mt-2">{template.name}</p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{template.description}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    <span className="rounded bg-slate-700 px-1.5 py-0.5 text-[9px] text-slate-400">
                      {template.settings.resolution}
                    </span>
                    <span className="rounded bg-slate-700 px-1.5 py-0.5 text-[9px] text-slate-400">
                      {template.settings.aspectRatio}
                    </span>
                  </div>
                </button>
              ))}
            </div>

            {selectedTemplate && (
              <div className="rounded-xl border border-indigo-600/30 bg-indigo-600/5 p-4 space-y-3">
                <div>
                  <p className="text-sm font-medium text-indigo-300">{selectedTemplate.name} — Scene Structure</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {selectedTemplate.sceneStructure.map((scene, i) => (
                      <span key={i} className="rounded-full bg-slate-800 px-2.5 py-1 text-[10px] text-slate-300">
                        {i + 1}. {scene}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Project name (optional)..."
                    className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-indigo-500"
                  />
                  <button
                    onClick={handleApplyTemplate}
                    className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-500"
                  >
                    <FiPlay size={14} />
                    Create Project
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
