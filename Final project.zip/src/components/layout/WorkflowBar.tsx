import { useAppStore, type WorkspaceTab } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import {
  getNextStep,
  getPreviousStep,
  getStepProgress,
  getStepByTab,
  WORKFLOW_STEPS,
} from '@/utils/workflow';
import { cn } from '@/utils/cn';
import { FiArrowRight, FiArrowLeft, FiCheck, FiCircle, FiClock } from 'react-icons/fi';

export default function WorkflowBar() {
  const { activeTab, setActiveTab, addNotification } = useAppStore();
  const { projects, currentProjectId } = useProjectStore();
  const currentProject = projects.find((p) => p.id === currentProjectId);

  const stepInfo = getStepByTab(activeTab);
  const progress = getStepProgress(activeTab);
  const nextStep = getNextStep(activeTab);
  const prevStep = getPreviousStep(activeTab);

  const isStepCompleted = (stepId: string): boolean => {
    if (!currentProject) return false;
    switch (stepId) {
      case 'plan': return true;
      case 'script': return currentProject.scripts.length > 0;
      case 'research': return true;
      case 'media': return currentProject.mediaAssets.length > 0;
      case 'edit': return currentProject.timeline.length > 0;
      case 'analyze': return true;
      case 'export': return false;
      default: return false;
    }
  };

  const handleNext = () => {
    if (nextStep) {
      setActiveTab(nextStep);
      const nextInfo = getStepByTab(nextStep);
      addNotification({
        message: `Moving to: ${nextInfo?.title || nextStep}`,
        type: 'info',
      });
    }
  };

  const handlePrev = () => {
    if (prevStep) {
      setActiveTab(prevStep);
    }
  };

  const handleStepClick = (tab: WorkspaceTab) => {
    setActiveTab(tab);
  };

  return (
    <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm">
      {/* Progress Bar */}
      <div className="px-4 py-2">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest">
            Workflow · Step {progress.current} of {progress.total}
          </span>
          {stepInfo && (
            <span className="flex items-center gap-1 text-[10px] text-slate-500">
              <FiClock size={10} />
              ~{stepInfo.estimatedTime}
            </span>
          )}
        </div>
        <div className="h-1 rounded-full bg-slate-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 transition-all duration-500"
            style={{ width: `${(progress.current / progress.total) * 100}%` }}
          />
        </div>
      </div>

      {/* Step Indicators */}
      <div className="flex items-center px-2 pb-2 gap-0.5 overflow-x-auto">
        {WORKFLOW_STEPS.map((step, i) => {
          const isActive = step.tab === activeTab;
          const isComplete = isStepCompleted(step.id);
          const isPast = i < progress.current - 1;

          return (
            <button
              key={step.id}
              onClick={() => handleStepClick(step.tab)}
              className={cn(
                'flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[11px] whitespace-nowrap transition-all flex-shrink-0',
                isActive
                  ? 'bg-violet-600/30 text-violet-300 font-medium ring-1 ring-violet-500/50'
                  : isComplete || isPast
                    ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                    : 'text-slate-600'
              )}
              title={`${step.title}: ${step.description}`}
            >
              <span className="text-xs">{step.emoji}</span>
              <span className="hidden sm:inline">{step.title}</span>
              {isComplete && !isActive && (
                <FiCheck size={10} className="text-emerald-400" />
              )}
              {isActive && !isComplete && (
                <FiCircle size={10} className="text-violet-400" />
              )}
            </button>
          );
        })}

        {/* Navigation Arrows */}
        <div className="ml-auto flex items-center gap-1 flex-shrink-0">
          {prevStep && (
            <button
              onClick={handlePrev}
              className="rounded p-1 text-slate-500 hover:text-white hover:bg-slate-800"
              title="Previous Step"
            >
              <FiArrowLeft size={14} />
            </button>
          )}
          {nextStep && (
            <button
              onClick={handleNext}
              className="flex items-center gap-1 rounded bg-violet-600 px-2.5 py-1 text-[11px] font-medium text-white hover:bg-violet-500"
              title={`Next: ${getStepByTab(nextStep)?.title}`}
            >
              Next
              <FiArrowRight size={12} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
