import { useAppStore, type WorkspaceTab } from '@/stores/appStore';
import { cn } from '@/utils/cn';
import {
  FiGrid,
  FiEdit3,
  FiSearch,
  FiImage,
  FiVideo,
  FiBarChart2,
  FiFolder,
  FiShare2,
  FiUsers,
} from 'react-icons/fi';

const navItems: { id: WorkspaceTab; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <FiGrid size={18} /> },
  { id: 'scriptwriter', label: 'Script Writer', icon: <FiEdit3 size={18} /> },
  { id: 'research', label: 'Research', icon: <FiSearch size={18} /> },
  { id: 'media', label: 'Media Studio', icon: <FiImage size={18} /> },
  { id: 'video-editor', label: 'Video Editor', icon: <FiVideo size={18} /> },
  { id: 'analysis', label: 'AI Analysis', icon: <FiBarChart2 size={18} /> },
  { id: 'assets', label: 'Assets', icon: <FiFolder size={18} /> },
  { id: 'export', label: 'Export & Share', icon: <FiShare2 size={18} /> },
  { id: 'collaboration', label: 'Collaboration', icon: <FiUsers size={18} /> },
];

export default function Sidebar() {
  const { activeTab, setActiveTab, sidebarCollapsed } = useAppStore();

  return (
    <aside
      className={cn(
        'flex flex-col border-r border-slate-800 bg-slate-950 transition-all duration-300',
        sidebarCollapsed ? 'w-16' : 'w-60'
      )}
    >
      <div className="flex h-14 items-center gap-3 border-b border-slate-800 px-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 text-sm font-bold text-white">
          MX
        </div>
        {!sidebarCollapsed && (
          <span className="text-sm font-semibold text-white">MediaForge AI</span>
        )}
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto p-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              'flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all',
              activeTab === item.id
                ? 'bg-violet-600/20 text-violet-400 font-medium'
                : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
            )}
          >
            <span className="flex-shrink-0">{item.icon}</span>
            {!sidebarCollapsed && <span>{item.label}</span>}
          </button>
        ))}
      </nav>
      <div className="border-t border-slate-800 p-3">
        {!sidebarCollapsed && (
          <div className="rounded-lg bg-slate-900 p-3 text-xs text-slate-500">
            <p className="font-medium text-slate-400">WASM Powered</p>
            <p className="mt-1">FFmpeg.wasm + Transformers.js</p>
            <p>100% Client-Side Processing</p>
          </div>
        )}
      </div>
    </aside>
  );
}
