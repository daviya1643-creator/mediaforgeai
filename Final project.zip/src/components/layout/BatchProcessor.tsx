import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { useAssetStore } from '@/stores/assetStore';
import { cn } from '@/utils/cn';
import { FiCpu, FiPlay, FiX, FiCheck, FiImage, FiVideo, FiZap } from 'react-icons/fi';

interface BatchJob {
  id: string;
  assetId: string;
  operation: string;
  status: 'pending' | 'running' | 'done';
  progress: number;
  result?: string;
}

type BatchOperation = 'style-transfer' | 'resize' | 'format-convert' | 'watermark';

export default function BatchProcessor() {
  const { addNotification } = useAppStore();
  const { assets } = useAssetStore();
  const [isOpen, setIsOpen] = useState(false);
  const [jobs, setJobs] = useState<BatchJob[]>([]);
  const [selectedOp, setSelectedOp] = useState<BatchOperation>('style-transfer');
  const [isRunning, setIsRunning] = useState(false);

  const filteredAssets = assets.filter((a) => a.type === 'image' || a.type === 'video');

  const operations: { id: BatchOperation; name: string; icon: React.ReactNode; desc: string }[] = [
    { id: 'style-transfer', name: 'Style Transfer', icon: <FiZap size={12} />, desc: 'Apply cinematic style to all' },
    { id: 'resize', name: 'Resize All', icon: <FiImage size={12} />, desc: 'Resize to target resolution' },
    { id: 'format-convert', name: 'Format Convert', icon: <FiVideo size={12} />, desc: 'Convert all to MP4' },
    { id: 'watermark', name: 'Add Watermark', icon: <FiImage size={12} />, desc: 'Brand all assets' },
  ];

  const startBatch = () => {
    if (filteredAssets.length === 0) {
      addNotification({ message: 'No assets to process', type: 'error' });
      return;
    }

    const newJobs: BatchJob[] = filteredAssets.map((asset) => ({
      id: `job_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      assetId: asset.id,
      operation: selectedOp,
      status: 'pending',
      progress: 0,
    }));

    setJobs(newJobs);
    setIsRunning(true);
    runBatch(newJobs);
  };

  const runBatch = async (jobList: BatchJob[]) => {
    for (const job of jobList) {
      setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, status: 'running' as const } : j));

      // Simulate processing
      await new Promise<void>((resolve) => {
        let p = 0;
        const interval = setInterval(() => {
          p += Math.random() * 30 + 10;
          if (p >= 100) {
            p = 100;
            clearInterval(interval);
            setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, status: 'done' as const, progress: 100 } : j));
            resolve();
          } else {
            setJobs((prev) => prev.map((j) => j.id === job.id ? { ...j, progress: Math.floor(p) } : j));
          }
        }, 300);
      });
    }

    setIsRunning(false);
    addNotification({ message: `Batch complete: ${jobList.length} assets processed`, type: 'success' });
  };

  const completedCount = jobs.filter((j) => j.status === 'done').length;

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-1.5 rounded-lg bg-amber-600/10 border border-amber-600/30 px-3 py-1.5 text-xs text-amber-400 hover:bg-amber-600/20 transition-all"
        title="Batch Process Multiple Assets"
      >
        <FiCpu size={12} />
        Batch
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => !isRunning && setIsOpen(false)}>
          <div className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Batch Processor</h3>
              <button onClick={() => !isRunning && setIsOpen(false)} className="text-slate-400 hover:text-white">
                <FiX size={18} />
              </button>
            </div>

            {/* Operation Selector */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              {operations.map((op) => (
                <button
                  key={op.id}
                  onClick={() => !isRunning && setSelectedOp(op.id)}
                  className={cn(
                    'rounded-lg p-3 text-left transition-all border',
                    selectedOp === op.id
                      ? 'border-violet-500 bg-violet-600/10'
                      : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                  )}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-violet-400">{op.icon}</span>
                    <span className="text-sm font-medium text-white">{op.name}</span>
                  </div>
                  <p className="text-[10px] text-slate-500">{op.desc}</p>
                </button>
              ))}
            </div>

            {/* Asset Count */}
            <div className="rounded-lg bg-slate-800 p-3 mb-4 text-sm text-slate-300">
              <span className="font-medium text-white">{filteredAssets.length}</span> assets ready for batch processing
            </div>

            {/* Job List */}
            {jobs.length > 0 && (
              <div className="space-y-1.5 mb-4 max-h-48 overflow-y-auto">
                {jobs.map((job) => {
                  const asset = assets.find((a) => a.id === job.assetId);
                  return (
                    <div key={job.id} className="flex items-center gap-2 rounded bg-slate-800 px-3 py-2 text-xs">
                      <span className="text-slate-400 truncate flex-1">{asset?.name || 'Unknown'}</span>
                      {job.status === 'pending' && <span className="text-slate-500">Waiting</span>}
                      {job.status === 'running' && (
                        <div className="flex items-center gap-1.5">
                          <div className="h-1 w-16 rounded-full bg-slate-700 overflow-hidden">
                            <div className="h-full bg-violet-500 transition-all" style={{ width: `${job.progress}%` }} />
                          </div>
                          <span className="text-violet-400">{job.progress}%</span>
                        </div>
                      )}
                      {job.status === 'done' && <FiCheck size={14} className="text-emerald-400" />}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Progress Summary */}
            {jobs.length > 0 && (
              <div className="mb-4 text-xs text-slate-400">
                {completedCount} / {jobs.length} completed
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={startBatch}
                disabled={isRunning || filteredAssets.length === 0}
                className="flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50 flex-1 justify-center"
              >
                <FiPlay size={14} />
                {isRunning ? 'Processing...' : 'Start Batch'}
              </button>
              <button
                onClick={() => !isRunning && setIsOpen(false)}
                className="rounded-lg bg-slate-800 px-4 py-2.5 text-sm text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
