import { useState, useEffect } from 'react';
import { useProjectStore } from '@/stores/projectStore';
import { useAssetStore } from '@/stores/assetStore';
import { autoSave } from '@/utils/persistence';
import { FiSave, FiCheck, FiCloud } from 'react-icons/fi';

export default function AutoSaveIndicator() {
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved'>('idle');
  const projects = useProjectStore((s) => s.projects);
  const assets = useAssetStore((s) => s.assets);

  useEffect(() => {
    const interval = setInterval(() => {
      if (projects.length > 0 || assets.length > 0) {
        setSaveState('saving');
        autoSave('projects', projects);
        autoSave('assets', assets.map((a) => ({
          id: a.id,
          name: a.name,
          type: a.type,
          size: a.size,
          tags: a.tags,
          createdAt: a.createdAt,
        })));

        setTimeout(() => {
          setSaveState('saved');
          setTimeout(() => setSaveState('idle'), 2000);
        }, 600);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [projects, assets]);

  return (
    <div className="flex items-center gap-1.5">
      {saveState === 'saving' && (
        <span className="flex items-center gap-1 text-[10px] text-amber-400">
          <FiSave size={10} className="animate-pulse" />
          Saving...
        </span>
      )}
      {saveState === 'saved' && (
        <span className="flex items-center gap-1 text-[10px] text-emerald-400">
          <FiCheck size={10} />
          Saved
        </span>
      )}
      {saveState === 'idle' && (
        <span className="flex items-center gap-1 text-[10px] text-slate-600">
          <FiCloud size={10} />
        </span>
      )}
    </div>
  );
}
