import { useState, useRef } from 'react';
import { useAppStore } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import { generateText, generateScriptOutline, analyzeSentiment } from '@/utils/ai';
import { cn } from '@/utils/cn';
import { FiCpu, FiPlay, FiSave, FiPlus, FiTrash2, FiCopy, FiDownload, FiEdit } from 'react-icons/fi';

export default function ScriptWriter() {
  const { addNotification, isAILoading, setAILoading } = useAppStore();
  const { projects, currentProjectId, addScriptItem, updateScriptItem, removeScriptItem } = useProjectStore();
  const currentProject = projects.find((p) => p.id === currentProjectId);
  const scripts = currentProject?.scripts || [];

  const [prompt, setPrompt] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [sentiment, setSentiment] = useState<{ label: string; score: number } | null>(null);
  const [activeMode, setActiveMode] = useState<'generate' | 'outline' | 'editor'>('generate');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setAILoading(true);
    try {
      const text = await generateText(prompt, 200);
      setGeneratedText(text);
      const s = await analyzeSentiment(text);
      setSentiment(s);
      addNotification({ message: 'AI script generated successfully', type: 'success' });
    } catch {
      addNotification({ message: 'AI generation completed (offline mode)', type: 'info' });
    }
    setAILoading(false);
  };

  const handleGenerateOutline = async () => {
    if (!prompt.trim()) return;
    setAILoading(true);
    try {
      const outline = await generateScriptOutline(prompt);
      setGeneratedText(outline);
      addNotification({ message: 'Script outline generated', type: 'success' });
    } catch {
      addNotification({ message: 'Outline generated in offline mode', type: 'info' });
    }
    setAILoading(false);
  };

  const handleSaveToProject = () => {
    if (!currentProjectId) {
      addNotification({ message: 'Create a project first!', type: 'error' });
      return;
    }
    const content = generatedText || prompt;
    if (!content.trim()) return;
    addScriptItem(currentProjectId, {
      content,
      type: 'scene',
      order: scripts.length,
      aiGenerated: true,
    });
    addNotification({ message: 'Saved to project', type: 'success' });
    setGeneratedText('');
    setPrompt('');
  };

  const handleStartEdit = (id: string, content: string) => {
    setEditingId(id);
    setEditContent(content);
    setTimeout(() => textareaRef.current?.focus(), 50);
  };

  const handleSaveEdit = () => {
    if (!currentProjectId || !editingId) return;
    updateScriptItem(currentProjectId, editingId, editContent);
    setEditingId(null);
    setEditContent('');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    addNotification({ message: 'Copied to clipboard', type: 'info' });
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Script Writer</h1>
          <p className="text-sm text-slate-400 mt-1">
            Powered by transformers.js — local AI, no API keys required
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isAILoading && (
            <div className="flex items-center gap-2 rounded-full bg-amber-600/20 px-3 py-1 text-xs text-amber-400">
              <FiCpu size={12} className="animate-spin" />
              AI Thinking...
            </div>
          )}
        </div>
      </div>

      {/* Mode Tabs */}
      <div className="flex gap-1 rounded-lg bg-slate-900 p-1 w-fit">
        {(['generate', 'outline', 'editor'] as const).map((mode) => (
          <button
            key={mode}
            onClick={() => setActiveMode(mode)}
            className={cn(
              'rounded-md px-4 py-2 text-sm font-medium transition-all',
              activeMode === mode ? 'bg-violet-600 text-white' : 'text-slate-400 hover:text-white'
            )}
          >
            {mode === 'generate' ? 'Generate' : mode === 'outline' ? 'Outline' : 'Script Editor'}
          </button>
        ))}
      </div>

      {(activeMode === 'generate' || activeMode === 'outline') && (
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <label className="text-sm font-medium text-slate-300 mb-2 block">
              {activeMode === 'generate' ? 'Describe your scene or story' : 'What topic should the outline cover?'}
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={activeMode === 'generate'
                ? 'E.g., A tense confrontation between two rival hackers in a neon-lit cyberpunk city...'
                : 'E.g., The future of AI in creative industries...'}
              rows={4}
              className="w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-3 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500 resize-none"
            />
            <div className="flex gap-2 mt-3">
              <button
                onClick={activeMode === 'generate' ? handleGenerate : handleGenerateOutline}
                disabled={isAILoading || !prompt.trim()}
                className="flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50 transition-all"
              >
                <FiCpu size={14} />
                {activeMode === 'generate' ? 'Generate Script' : 'Generate Outline'}
              </button>
              {generatedText && (
                <button
                  onClick={handleSaveToProject}
                  className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-500"
                >
                  <FiSave size={14} />
                  Save to Project
                </button>
              )}
            </div>
          </div>

          {generatedText && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-white">Generated Output</h3>
                <div className="flex gap-1">
                  <button onClick={() => handleCopy(generatedText)} className="rounded p-1.5 text-slate-400 hover:text-white hover:bg-slate-800">
                    <FiCopy size={14} />
                  </button>
                  <button
                    onClick={() => {
                      const blob = new Blob([generatedText], { type: 'text/plain' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url; a.download = 'script.txt'; a.click();
                      URL.revokeObjectURL(url);
                    }}
                    className="rounded p-1.5 text-slate-400 hover:text-white hover:bg-slate-800"
                  >
                    <FiDownload size={14} />
                  </button>
                </div>
              </div>
              <div className="rounded-lg bg-slate-950 p-4 text-sm text-slate-300 leading-relaxed whitespace-pre-wrap max-h-80 overflow-y-auto">
                {generatedText}
              </div>
              {sentiment && (
                <div className="flex items-center gap-3 mt-3 text-xs">
                  <span className="text-slate-500">AI Sentiment Analysis:</span>
                  <span className={cn(
                    'rounded-full px-2 py-0.5 font-medium',
                    sentiment.label === 'POSITIVE' ? 'bg-emerald-600/20 text-emerald-400' :
                    sentiment.label === 'NEGATIVE' ? 'bg-red-600/20 text-red-400' :
                    'bg-slate-700 text-slate-300'
                  )}>
                    {sentiment.label} ({(sentiment.score * 100).toFixed(0)}%)
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {activeMode === 'editor' && (
        <div className="space-y-3">
          {!currentProjectId ? (
            <div className="rounded-xl border border-dashed border-slate-700 p-12 text-center">
              <FiPlay size={40} className="mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400 font-medium">No project selected</p>
              <p className="text-sm text-slate-500 mt-1">Create a project from the Dashboard first, then return here to edit scripts.</p>
            </div>
          ) : scripts.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-700 p-12 text-center">
              <p className="text-slate-400">No scripts yet. Generate one above!</p>
            </div>
          ) : (
            scripts.map((item) => (
              <div key={item.id} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-medium text-slate-500">Scene {item.order + 1}</span>
                    <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-400">{item.type}</span>
                    {item.aiGenerated && (
                      <span className="rounded-full bg-violet-600/20 px-2 py-0.5 text-[10px] text-violet-400">AI</span>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleStartEdit(item.id, item.content)}
                      className="rounded p-1 text-slate-400 hover:text-white hover:bg-slate-800"
                    >
                      <FiEdit size={14} />
                    </button>
                    <button
                      onClick={() => currentProjectId && removeScriptItem(currentProjectId, item.id)}
                      className="rounded p-1 text-slate-400 hover:text-red-400 hover:bg-slate-800"
                    >
                      <FiTrash2 size={14} />
                    </button>
                  </div>
                </div>
                {editingId === item.id ? (
                  <div>
                    <textarea
                      ref={textareaRef}
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      rows={4}
                      className="w-full rounded-lg border border-violet-600 bg-slate-800 px-3 py-2 text-sm text-white outline-none resize-none"
                    />
                    <div className="flex gap-2 mt-2">
                      <button onClick={handleSaveEdit} className="rounded bg-violet-600 px-3 py-1 text-xs text-white">Save</button>
                      <button onClick={() => setEditingId(null)} className="rounded bg-slate-700 px-3 py-1 text-xs text-slate-300">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-slate-300 leading-relaxed">{item.content}</p>
                )}
              </div>
            ))
          )}
          {currentProjectId && (
            <button
              onClick={() => {
                addScriptItem(currentProjectId, {
                  content: 'New scene...',
                  type: 'scene',
                  order: scripts.length,
                  aiGenerated: false,
                });
              }}
              className="flex items-center gap-2 rounded-lg border border-dashed border-slate-700 p-3 text-sm text-slate-400 hover:border-slate-500 hover:text-white w-full justify-center"
            >
              <FiPlus size={14} />
              Add New Scene
            </button>
          )}
        </div>
      )}
    </div>
  );
}

