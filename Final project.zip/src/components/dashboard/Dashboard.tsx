import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import { useAssetStore } from '@/stores/assetStore';
import { cn } from '@/utils/cn';
import {
  FiPlus,
  FiTrendingUp,
  FiClock,
  FiCpu,
  FiPlay,
  FiImage,
  FiEdit3,
  FiZap,
  FiHardDrive,
  FiActivity,
  FiCommand,
} from 'react-icons/fi';

export default function Dashboard() {
  const { setActiveTab, addNotification } = useAppStore();
  const { projects, createProject } = useProjectStore();
  const { assets } = useAssetStore();
  const [showNewProject, setShowNewProject] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');

  const stats = [
    { label: 'Projects', value: projects.length, icon: <FiTrendingUp size={20} />, color: 'text-violet-400', bg: 'bg-violet-600/10' },
    { label: 'Assets', value: assets.length, icon: <FiHardDrive size={20} />, color: 'text-emerald-400', bg: 'bg-emerald-600/10' },
    { label: 'AI Models', value: '4 Ready', icon: <FiCpu size={20} />, color: 'text-amber-400', bg: 'bg-amber-600/10' },
    { label: 'WASM', value: 'Active', icon: <FiZap size={20} />, color: 'text-sky-400', bg: 'bg-sky-600/10' },
  ];

  const quickActions = [
    { label: 'New Project', icon: <FiPlus size={16} />, action: () => setShowNewProject(true), color: 'bg-violet-600 hover:bg-violet-500' },
    { label: 'Script Writer', icon: <FiEdit3 size={16} />, action: () => setActiveTab('scriptwriter'), color: 'bg-indigo-600 hover:bg-indigo-500' },
    { label: 'Media Studio', icon: <FiImage size={16} />, action: () => setActiveTab('media'), color: 'bg-pink-600 hover:bg-pink-500' },
    { label: 'Video Editor', icon: <FiPlay size={16} />, action: () => setActiveTab('video-editor'), color: 'bg-emerald-600 hover:bg-emerald-500' },
    { label: 'AI Analysis', icon: <FiActivity size={16} />, action: () => setActiveTab('analysis'), color: 'bg-amber-600 hover:bg-amber-500' },
  ];

  const recentProjects = projects.slice(-5).reverse();

  const handleCreateProject = () => {
    if (!newProjectName.trim()) return;
    createProject({
      name: newProjectName,
      description: '',
      type: 'mixed',
      status: 'draft',
      scripts: [],
      mediaAssets: [],
      timeline: [],
      settings: {
        resolution: '1080p',
        frameRate: 30,
        format: 'mp4',
        quality: 'high',
        aspectRatio: '16:9',
      },
    });
    addNotification({ message: `Project "${newProjectName}" created!`, type: 'success' });
    setNewProjectName('');
    setShowNewProject(false);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-sm text-slate-400 mt-1">
            Welcome to MediaForge AI — Professional Multimedia Workflow Platform
          </p>
        </div>
        <button
          onClick={() => setShowNewProject(true)}
          className="flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 transition-colors"
        >
          <FiPlus size={16} />
          New Project
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">{stat.label}</span>
              <div className={cn('rounded-lg p-2', stat.bg, stat.color)}>{stat.icon}</div>
            </div>
            <p className="text-2xl font-bold text-white mt-2">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">Quick Actions</h2>
        <div className="flex flex-wrap gap-2">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={action.action}
              className={cn(
                'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium text-white transition-all',
                action.color
              )}
            >
              {action.icon}
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <FeatureCard
          icon={<FiCpu size={24} />}
          title="AI-Powered Script Writing"
          description="Generate scripts, dialogue, and scene outlines using transformers.js running locally in your browser."
          status="Ready"
          statusColor="emerald"
        />
        <FeatureCard
          icon={<FiImage size={24} />}
          title="Media Generation Studio"
          description="Create and edit images with AI style transfer, color correction, and automatic scene detection."
          status="Ready"
          statusColor="emerald"
        />
        <FeatureCard
          icon={<FiPlay size={24} />}
          title="WASM Video Editor"
          description="Full timeline editor powered by FFmpeg.wasm. Trim, convert, and process video without any server."
          status="Active"
          statusColor="amber"
        />
        <FeatureCard
          icon={<FiActivity size={24} />}
          title="AI Content Analysis"
          description="Sentiment analysis, scene detection, zero-shot classification for intelligent media understanding."
          status="Ready"
          statusColor="emerald"
        />
        <FeatureCard
          icon={<FiZap size={24} />}
          title="Style Transfer Engine"
          description="Apply cinematic, vintage, cyberpunk, anime, and noir styles with real-time preview."
          status="Ready"
          statusColor="emerald"
        />
        <FeatureCard
          icon={<FiEdit3 size={24} />}
          title="Auto Editing Suite"
          description="Automatic color correction, scene trimming, and smart transitions based on content analysis."
          status="Beta"
          statusColor="violet"
        />
      </div>

      {/* Keyboard Shortcuts */}
      <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
        <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
          <FiCommand size={14} className="text-amber-400" />
          Keyboard Shortcuts
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
          {[
            { combo: 'Ctrl+S', desc: 'Save project' },
            { combo: 'Ctrl+Z', desc: 'Undo' },
            { combo: 'Ctrl+Shift+Z', desc: 'Redo' },
            { combo: 'Ctrl+→', desc: 'Next step' },
            { combo: 'Ctrl+←', desc: 'Prev step' },
            { combo: 'Ctrl+B', desc: 'Toggle sidebar' },
            { combo: 'Ctrl+N', desc: 'New project' },
            { combo: 'Ctrl+Enter', desc: 'AI Generate' },
          ].map((shortcut) => (
            <div key={shortcut.combo} className="flex items-center gap-2 rounded-lg bg-slate-800 px-3 py-2">
              <kbd className="rounded bg-slate-700 px-1.5 py-0.5 text-[10px] font-mono text-violet-400">{shortcut.combo}</kbd>
              <span className="text-[10px] text-slate-400">{shortcut.desc}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Projects */}
      <div>
        <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">Recent Projects</h2>
        {recentProjects.length === 0 ? (
          <div className="rounded-xl border border-dashed border-slate-700 p-8 text-center">
            <FiClock size={32} className="mx-auto text-slate-600 mb-3" />
            <p className="text-slate-500">No projects yet. Create your first project to get started.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {recentProjects.map((project) => (
              <div
                key={project.id}
                className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900 p-3 hover:border-slate-700 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium text-white">{project.name}</p>
                  <p className="text-xs text-slate-500">
                    {project.type} · {project.status} · {new Date(project.updatedAt).toLocaleDateString()}
                  </p>
                </div>
                <span className={cn(
                  'rounded-full px-2 py-0.5 text-[10px] font-medium',
                  project.status === 'draft' ? 'bg-slate-700 text-slate-300' :
                  project.status === 'in-progress' ? 'bg-amber-600/20 text-amber-400' :
                  project.status === 'review' ? 'bg-violet-600/20 text-violet-400' :
                  'bg-emerald-600/20 text-emerald-400'
                )}>
                  {project.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* New Project Modal */}
      {showNewProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
            <h3 className="text-lg font-semibold text-white mb-4">Create New Project</h3>
            <input
              autoFocus
              type="text"
              placeholder="Project name..."
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreateProject()}
              className="w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
            />
            <div className="flex justify-end gap-2 mt-4">
              <button
                onClick={() => setShowNewProject(false)}
                className="rounded-lg px-4 py-2 text-sm text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateProject}
                className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
  status,
  statusColor,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  status: string;
  statusColor: string;
}) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-5 hover:border-slate-700 transition-colors">
      <div className="flex items-start justify-between mb-3">
        <div className="text-violet-400">{icon}</div>
        <span className={cn(
          'rounded-full px-2 py-0.5 text-[10px] font-medium',
          statusColor === 'emerald' ? 'bg-emerald-600/20 text-emerald-400' :
          statusColor === 'amber' ? 'bg-amber-600/20 text-amber-400' :
          'bg-violet-600/20 text-violet-400'
        )}>
          {status}
        </span>
      </div>
      <h3 className="text-sm font-semibold text-white mb-1">{title}</h3>
      <p className="text-xs text-slate-400 leading-relaxed">{description}</p>
    </div>
  );
}
