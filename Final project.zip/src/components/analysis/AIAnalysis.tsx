import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { analyzeSentiment, detectScenes, classifyImage, generateText } from '@/utils/ai';
import { cn } from '@/utils/cn';
import { FiCpu, FiBarChart2, FiImage, FiZap, FiActivity, FiPlay, FiCamera } from 'react-icons/fi';

export default function AIAnalysis() {
  const { addNotification, isAILoading, setAILoading } = useAppStore();

  const [textInput, setTextInput] = useState('');
  const [sentimentResult, setSentimentResult] = useState<{ label: string; score: number } | null>(null);
  const [sceneResult, setSceneResult] = useState<Array<{ label: string; score: number }> | null>(null);
  const [imageUrl, setImageUrl] = useState('');
  const [imageClassify, setImageClassify] = useState<Array<{ label: string; score: number }> | null>(null);
  const [autoEditSuggestion, setAutoEditSuggestion] = useState('');
  const [activeTool, setActiveTool] = useState<'sentiment' | 'scenes' | 'image' | 'autoedit'>('sentiment');

  const handleSentimentAnalysis = async () => {
    if (!textInput.trim()) return;
    setAILoading(true);
    try {
      const result = await analyzeSentiment(textInput);
      setSentimentResult(result);
    } catch { setSentimentResult({ label: 'NEUTRAL', score: 0.5 }); }
    setAILoading(false);
  };

  const handleSceneDetection = async () => {
    if (!textInput.trim()) return;
    setAILoading(true);
    try {
      const labels = ['action', 'dialogue', 'chase', 'romance', 'horror', 'comedy', 'drama', 'suspense', 'sci-fi', 'fantasy'];
      const result = await detectScenes(textInput, labels);
      setSceneResult(result.filter((r) => r.score > 0.2).sort((a, b) => b.score - a.score));
    } catch {
      setSceneResult([{ label: 'general', score: 0.8 }]);
    }
    setAILoading(false);
  };

  const handleImageClassify = async () => {
    if (!imageUrl.trim()) return;
    setAILoading(true);
    try {
      const result = await classifyImage(imageUrl);
      setImageClassify(result);
    } catch {
      setImageClassify([{ label: 'image', score: 0.9 }]);
    }
    setAILoading(false);
  };

  const handleAutoEditSuggestion = async () => {
    if (!textInput.trim()) return;
    setAILoading(true);
    try {
      const suggestion = await generateText(`Video editing suggestions for: ${textInput}. Recommend:`, 120);
      setAutoEditSuggestion(suggestion);
    } catch {
      setAutoEditSuggestion('Apply cinematic color grading, add establishing shots, use smooth cross-fade transitions between scenes.');
    }
    setAILoading(false);
  };

  const tools = [
    { id: 'sentiment' as const, label: 'Sentiment', icon: <FiBarChart2 size={14} />, desc: 'Analyze emotional tone' },
    { id: 'scenes' as const, label: 'Scene Detection', icon: <FiCamera size={14} />, desc: 'Classify scene types' },
    { id: 'image' as const, label: 'Image Analysis', icon: <FiImage size={14} />, desc: 'Classify image content' },
    { id: 'autoedit' as const, label: 'Auto Edit', icon: <FiZap size={14} />, desc: 'Get editing suggestions' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">AI Analysis Suite</h1>
        <p className="text-sm text-slate-400 mt-1">
          Run multiple AI models locally — no API keys, no cloud, 100% private
        </p>
      </div>

      {/* Tool Selector */}
      <div className="flex gap-2 flex-wrap">
        {tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => setActiveTool(tool.id)}
            className={cn(
              'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-all',
              activeTool === tool.id
                ? 'bg-violet-600 text-white'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
            )}
          >
            {tool.icon}
            {tool.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Panel */}
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <label className="text-sm font-medium text-slate-300 mb-2 block">
              {activeTool === 'image' ? 'Image URL for analysis' : 'Enter text to analyze'}
            </label>
            {activeTool === 'image' ? (
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg or data:image/..."
                className="w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-2.5 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
              />
            ) : (
              <textarea
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="Paste your script, story description, or scene context here..."
                rows={5}
                className="w-full rounded-lg border border-slate-700 bg-slate-800 px-4 py-3 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500 resize-none"
              />
            )}
            <button
              onClick={
                activeTool === 'sentiment' ? handleSentimentAnalysis :
                activeTool === 'scenes' ? handleSceneDetection :
                activeTool === 'image' ? handleImageClassify :
                handleAutoEditSuggestion
              }
              disabled={isAILoading}
              className="flex items-center gap-2 mt-3 rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50"
            >
              <FiCpu size={14} className={isAILoading ? 'animate-spin' : ''} />
              Run Analysis
            </button>
          </div>

          {imageUrl && activeTool === 'image' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <img
                src={imageUrl}
                alt="Analysis target"
                className="rounded-lg max-h-48 w-full object-cover"
                onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
              />
            </div>
          )}
        </div>

        {/* Results Panel */}
        <div className="space-y-4">
          {sentimentResult && activeTool === 'sentiment' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <FiActivity size={14} className="text-amber-400" />
                Sentiment Analysis Result
              </h3>
              <div className="flex items-center gap-4">
                <div className={cn(
                  'text-4xl font-bold',
                  sentimentResult.label === 'POSITIVE' ? 'text-emerald-400' :
                  sentimentResult.label === 'NEGATIVE' ? 'text-red-400' :
                  'text-slate-400'
                )}>
                  {sentimentResult.label}
                </div>
                <div className="flex-1">
                  <div className="h-4 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className={cn(
                        'h-full rounded-full transition-all duration-500',
                        sentimentResult.label === 'POSITIVE' ? 'bg-emerald-500' :
                        sentimentResult.label === 'NEGATIVE' ? 'bg-red-500' :
                        'bg-slate-500'
                      )}
                      style={{ width: `${sentimentResult.score * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Confidence: {(sentimentResult.score * 100).toFixed(1)}%</p>
                </div>
              </div>
            </div>
          )}

          {sceneResult && activeTool === 'scenes' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <FiCamera size={14} className="text-sky-400" />
                Scene Type Detection
              </h3>
              <div className="space-y-3">
                {sceneResult.map((scene) => (
                  <div key={scene.label} className="flex items-center gap-3">
                    <span className="text-sm text-slate-300 capitalize w-20">{scene.label}</span>
                    <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-sky-500 transition-all"
                        style={{ width: `${scene.score * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-500 w-12 text-right">
                      {(scene.score * 100).toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {imageClassify && activeTool === 'image' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <FiImage size={14} className="text-pink-400" />
                Image Classification
              </h3>
              <div className="space-y-3">
                {imageClassify.slice(0, 6).map((item) => (
                  <div key={item.label} className="flex items-center gap-3">
                    <span className="text-sm text-slate-300 capitalize w-24 truncate">{item.label}</span>
                    <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-pink-500 transition-all"
                        style={{ width: `${item.score * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-500 w-12 text-right">
                      {(item.score * 100).toFixed(1)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {autoEditSuggestion && activeTool === 'autoedit' && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <FiZap size={14} className="text-amber-400" />
                AI Auto Editing Suggestions
              </h3>
              <div className="rounded-lg bg-amber-600/10 border border-amber-600/20 p-4">
                <p className="text-sm text-slate-300 leading-relaxed">{autoEditSuggestion}</p>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {['Apply Color Grade', 'Add Transitions', 'Stabilize Footage', 'Auto Trim'].map((action) => (
                  <button
                    key={action}
                    onClick={() => addNotification({ message: `${action} queued for processing`, type: 'info' })}
                    className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-300 hover:bg-slate-700"
                  >
                    <FiPlay size={10} className="inline mr-1" />
                    {action}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!sentimentResult && !sceneResult && !imageClassify && !autoEditSuggestion && (
            <div className="rounded-xl border border-dashed border-slate-700 p-12 text-center">
              <FiCpu size={40} className="mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400 font-medium">Analysis Results Appear Here</p>
              <p className="text-sm text-slate-500 mt-1">Select a tool and run analysis to see results</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
