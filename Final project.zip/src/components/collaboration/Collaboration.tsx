import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { cn } from '@/utils/cn';
import { FiUsers, FiPlus, FiCopy, FiLink, FiMessageCircle, FiUserPlus, FiWifi, FiClock, FiCheck, FiX } from 'react-icons/fi';

interface Collaborator {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'editor' | 'viewer';
  avatar: string;
  status: 'online' | 'offline' | 'editing';
  lastActive: Date;
}

interface Comment {
  id: string;
  author: string;
  text: string;
  timestamp: Date;
  resolved: boolean;
}

export default function Collaboration() {
  const { addNotification } = useAppStore();

  const [collaborators, setCollaborators] = useState<Collaborator[]>([
    { id: '1', name: 'You (Professor)', email: 'prof@mediaforge.ai', role: 'owner', avatar: 'P', status: 'online', lastActive: new Date() },
  ]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [comments, setComments] = useState<Comment[]>([
    { id: '1', author: 'System', text: 'Welcome to the collaboration space! Invite team members to work together.', timestamp: new Date(), resolved: false },
  ]);
  const [newComment, setNewComment] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [isHosting, setIsHosting] = useState(false);

  const handleInvite = () => {
    if (!inviteEmail.trim()) return;
    const newCollab: Collaborator = {
      id: Date.now().toString(),
      name: inviteEmail.split('@')[0],
      email: inviteEmail,
      role: 'editor',
      avatar: inviteEmail[0].toUpperCase(),
      status: 'offline',
      lastActive: new Date(),
    };
    setCollaborators((prev) => [...prev, newCollab]);
    setInviteEmail('');
    addNotification({ message: `Invited ${inviteEmail}`, type: 'success' });
  };

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    setComments((prev) => [...prev, {
      id: Date.now().toString(),
      author: 'You',
      text: newComment,
      timestamp: new Date(),
      resolved: false,
    }]);
    setNewComment('');
  };

  const handleToggleResolve = (commentId: string) => {
    setComments((prev) => prev.map((c) => c.id === commentId ? { ...c, resolved: !c.resolved } : c));
  };

  const handleStartSession = () => {
    const id = `session_${Date.now().toString(36)}`;
    setSessionId(id);
    setIsHosting(true);
    addNotification({ message: 'Collaboration session started! Share the session ID.', type: 'success' });
  };

  const handleCopySessionId = () => {
    navigator.clipboard.writeText(sessionId);
    addNotification({ message: 'Session ID copied!', type: 'info' });
  };

  const handleJoinSession = () => {
    if (!sessionId.trim()) return;
    addNotification({ message: `Joined session: ${sessionId}`, type: 'success' });
  };

  const roleBadge = (role: Collaborator['role']) => {
    const colors = {
      owner: 'bg-amber-600/20 text-amber-400',
      editor: 'bg-violet-600/20 text-violet-400',
      viewer: 'bg-slate-600/20 text-slate-400',
    };
    return (
      <span className={cn('rounded-full px-2 py-0.5 text-[10px] font-medium', colors[role])}>
        {role}
      </span>
    );
  };

  const statusDot = (status: Collaborator['status']) => {
    const colors = {
      online: 'bg-emerald-400',
      offline: 'bg-slate-600',
      editing: 'bg-amber-400 animate-pulse',
    };
    return <span className={cn('h-2 w-2 rounded-full', colors[status])} />;
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Collaboration</h1>
        <p className="text-sm text-slate-400 mt-1">
          Real-time collaboration via WebRTC · Peer-to-peer · No server required
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Team Members */}
        <div className="lg:col-span-1 space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <FiUsers size={14} className="text-sky-400" />
              Team ({collaborators.length})
            </h3>
            <div className="space-y-1">
              {collaborators.map((collab) => (
                <div key={collab.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-slate-800/50">
                  <div className="relative">
                    <div className="h-8 w-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white">
                      {collab.avatar}
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5">{statusDot(collab.status)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{collab.name}</p>
                    <p className="text-xs text-slate-500 truncate">{collab.email}</p>
                  </div>
                  {roleBadge(collab.role)}
                </div>
              ))}
            </div>

            <div className="mt-4 flex gap-2">
              <div className="flex-1 relative">
                <input
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleInvite()}
                  placeholder="colleague@email.com"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 pl-3 pr-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-violet-500"
                />
              </div>
              <button
                onClick={handleInvite}
                className="rounded-lg bg-violet-600 px-3 py-2 text-xs font-medium text-white hover:bg-violet-500"
              >
                <FiUserPlus size={12} />
              </button>
            </div>
          </div>

          {/* Session */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <FiWifi size={14} className="text-emerald-400" />
              Live Session
            </h3>
            {isHosting ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 rounded-lg bg-emerald-600/20 px-3 py-2">
                  <FiCheck size={14} className="text-emerald-400" />
                  <span className="text-xs text-emerald-400">Session Active</span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="flex-1 rounded bg-slate-800 px-3 py-2 text-xs text-violet-400 font-mono">{sessionId}</code>
                  <button onClick={handleCopySessionId} className="rounded p-2 text-slate-400 hover:text-white hover:bg-slate-800">
                    <FiCopy size={12} />
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={sessionId}
                    onChange={(e) => setSessionId(e.target.value)}
                    placeholder="Session ID to join..."
                    className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-violet-500"
                  />
                  <button
                    onClick={handleJoinSession}
                    className="rounded-lg bg-sky-600 px-3 py-2 text-xs font-medium text-white hover:bg-sky-500"
                  >
                    <FiLink size={12} />
                  </button>
                </div>
                <button
                  onClick={handleStartSession}
                  className="w-full rounded-lg bg-emerald-600 py-2 text-xs font-medium text-white hover:bg-emerald-500"
                >
                  <FiPlus size={12} className="inline mr-1" />
                  Start New Session
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Comments & Activity */}
        <div className="lg:col-span-2 space-y-4">
          {/* Comments */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <FiMessageCircle size={14} className="text-pink-400" />
              Comments ({comments.filter((c) => !c.resolved).length} open)
            </h3>
            <div className="space-y-2 max-h-80 overflow-y-auto mb-3">
              {comments.map((comment) => (
                <div
                  key={comment.id}
                  className={cn(
                    'rounded-lg p-3 transition-all',
                    comment.resolved ? 'bg-slate-800/30 opacity-60' : 'bg-slate-800'
                  )}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-slate-300">{comment.author}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500">
                        {comment.timestamp.toLocaleTimeString()}
                      </span>
                      <button
                        onClick={() => handleToggleResolve(comment.id)}
                        className={cn(
                          'rounded p-0.5',
                          comment.resolved ? 'text-emerald-400' : 'text-slate-500 hover:text-emerald-400'
                        )}
                      >
                        {comment.resolved ? <FiCheck size={12} /> : <FiX size={12} />}
                      </button>
                    </div>
                  </div>
                  <p className={cn('text-sm', comment.resolved ? 'text-slate-600 line-through' : 'text-slate-300')}>
                    {comment.text}
                  </p>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                placeholder="Add a comment..."
                className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
              />
              <button
                onClick={handleAddComment}
                disabled={!newComment.trim()}
                className="rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50"
              >
                Send
              </button>
            </div>
          </div>

          {/* Activity Log */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <FiClock size={14} className="text-amber-400" />
              Activity Log
            </h3>
            <div className="space-y-2 text-sm">
              {[
                { action: 'Project created', time: 'Just now', user: 'You' },
                { action: 'Session started', time: '5 min ago', user: 'You' },
                { action: 'Comment added', time: '10 min ago', user: 'System' },
              ].map((entry, i) => (
                <div key={i} className="flex items-center gap-2 text-xs">
                  <span className="w-1 h-1 rounded-full bg-slate-600" />
                  <span className="text-slate-400">{entry.user}</span>
                  <span className="text-slate-500">· {entry.action}</span>
                  <span className="text-slate-600 ml-auto">{entry.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
