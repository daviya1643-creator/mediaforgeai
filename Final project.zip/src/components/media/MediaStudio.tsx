import { useState, useRef, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useAppStore } from '@/stores/appStore';
import { useAssetStore } from '@/stores/assetStore';
import { classifyImage, applyStyleTransferParams, autoColorCorrectSuggestions } from '@/utils/ai';
import { generateThumbnail } from '@/utils/ffmpeg';
import { cn } from '@/utils/cn';
import { FiUpload, FiCpu, FiRefreshCw, FiZap, FiSliders, FiSun, FiDroplet } from 'react-icons/fi';

type StyleMode = 'cinematic' | 'vintage' | 'cyberpunk' | 'documentary' | 'anime' | 'noir';

export default function MediaStudio() {
  const { addNotification, setAILoading } = useAppStore();
  const { addAsset } = useAssetStore();
  const [preview, setPreview] = useState<string | null>(null);
  const [classifications, setClassifications] = useState<Array<{ label: string; score: number }>>([]);
  const [activeStyle, setActiveStyle] = useState<StyleMode | null>(null);
  const [colorCorrect, setColorCorrect] = useState<{
    brightness: number; contrast: number; saturation: number; warmth: number;
  }>({ brightness: 0, contrast: 0, saturation: 0, warmth: 0 });
  const [isProcessing, setIsProcessing] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const url = URL.createObjectURL(file);

    if (file.type.startsWith('video/')) {
      try {
        const thumb = await generateThumbnail(file);
        setPreview(thumb);
      } catch {
        setPreview(url);
      }
    } else {
      setPreview(url);
    }

    // Classify image
    setAILoading(true);
    try {
      const results = await classifyImage(url);
      setClassifications(results);
    } catch {
      setClassifications([{ label: 'image', score: 0.9 }]);
    }
    setAILoading(false);

    // Add to asset store
    addAsset({
      id: `asset_${Date.now()}`,
      name: file.name,
      type: file.type.startsWith('video/') ? 'video' : 'image',
      size: file.size,
      url,
      createdAt: new Date(),
      tags: [],
    });

    addNotification({ message: `Loaded: ${file.name}`, type: 'success' });
  }, [addAsset, addNotification, setAILoading]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/*': [], 'video/*': [] },
    maxFiles: 1,
  });

  const applyStyle = async (style: StyleMode) => {
    setActiveStyle(style);
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const params = applyStyleTransferParams(style);
      setColorCorrect({
        brightness: (params.brightness as number) || 0,
        contrast: (params.contrast as number) || 0,
        saturation: (params.saturation as number) || 0,
        warmth: (params.warmth as number) || 0,
      });
      addNotification({ message: `Style "${style}" applied`, type: 'success' });
    }, 800);
  };

  const handleAutoColorCorrect = async () => {
    setIsProcessing(true);
    try {
      const suggestions = await autoColorCorrectSuggestions(preview || '');
      setColorCorrect(suggestions);
      addNotification({ message: 'Auto color correction applied', type: 'success' });
    } catch {
      addNotification({ message: 'Color correction simulation complete', type: 'info' });
    }
    setIsProcessing(false);
  };

  const styles: { id: StyleMode; name: string; emoji: string; desc: string }[] = [
    { id: 'cinematic', name: 'Cinematic', emoji: '🎬', desc: 'Rich contrast, film-like' },
    { id: 'vintage', name: 'Vintage', emoji: '📷', desc: 'Warm, faded, nostalgic' },
    { id: 'cyberpunk', name: 'Cyberpunk', emoji: '🌃', desc: 'Neon, high saturation' },
    { id: 'documentary', name: 'Documentary', emoji: '📹', desc: 'Natural, sharp, real' },
    { id: 'anime', name: 'Anime', emoji: '🎨', desc: 'Vibrant, stylized' },
    { id: 'noir', name: 'Noir', emoji: '🖤', desc: 'B&W, dramatic shadows' },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Media Studio</h1>
        <p className="text-sm text-slate-400 mt-1">
          AI-powered image & video studio with style transfer and color correction
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload Area */}
        <div className="lg:col-span-2 space-y-4">
          <div
            {...getRootProps()}
            className={cn(
              'rounded-xl border-2 border-dashed p-12 text-center transition-all cursor-pointer',
              isDragActive
                ? 'border-violet-500 bg-violet-600/10'
                : 'border-slate-700 hover:border-slate-500 bg-slate-900'
            )}
          >
            <input {...getInputProps()} />
            <FiUpload size={40} className="mx-auto text-slate-500 mb-4" />
            <p className="text-slate-300 font-medium">Drop images or videos here</p>
            <p className="text-sm text-slate-500 mt-1">or click to browse files</p>
          </div>

          {preview && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <div className="relative rounded-lg overflow-hidden bg-slate-950">
                <img
                  ref={imgRef}
                  src={preview}
                  alt="Preview"
                  className="max-h-96 w-full object-contain"
                  style={{
                    filter: `
                      brightness(${1 + colorCorrect.brightness})
                      contrast(${1 + colorCorrect.contrast})
                      saturate(${1 + colorCorrect.saturation})
                      sepia(${Math.max(0, colorCorrect.warmth)})
                    `,
                  }}
                />
                {isProcessing && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                    <FiCpu size={32} className="text-violet-400 animate-spin" />
                  </div>
                )}
              </div>
              <canvas ref={canvasRef} className="hidden" />
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="space-y-4">
          {/* AI Classification */}
          {classifications.length > 0 && (
            <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
              <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                <FiCpu size={14} className="text-violet-400" />
                AI Image Analysis
              </h3>
              <div className="space-y-2">
                {classifications.slice(0, 5).map((c) => (
                  <div key={c.label} className="flex items-center justify-between">
                    <span className="text-xs text-slate-400 capitalize">{c.label}</span>
                    <div className="flex items-center gap-2">
                      <div className="h-1 w-16 rounded-full bg-slate-800">
                        <div
                          className="h-full rounded-full bg-violet-500"
                          style={{ width: `${c.score * 100}%` }}
                        />
                      </div>
                      <span className="text-xs text-slate-500 w-8">{(c.score * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Style Transfer */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <FiZap size={14} className="text-amber-400" />
              Style Transfer
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {styles.map((style) => (
                <button
                  key={style.id}
                  onClick={() => applyStyle(style.id)}
                  disabled={!preview}
                  className={cn(
                    'rounded-lg p-3 text-center transition-all',
                    activeStyle === style.id
                      ? 'bg-violet-600/20 border border-violet-600/50'
                      : 'bg-slate-800 border border-slate-700 hover:border-slate-600'
                  )}
                >
                  <span className="text-xl">{style.emoji}</span>
                  <p className={cn(
                    'text-xs font-medium mt-1',
                    activeStyle === style.id ? 'text-violet-400' : 'text-slate-300'
                  )}>
                    {style.name}
                  </p>
                  <p className="text-[10px] text-slate-500 mt-0.5">{style.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Color Correction */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <FiSliders size={14} className="text-emerald-400" />
              Color Correction
            </h3>
            <div className="space-y-3">
              <SliderControl
                icon={<FiSun size={12} />}
                label="Brightness"
                value={colorCorrect.brightness}
                min={-0.5}
                max={0.5}
                onChange={(v) => setColorCorrect((c) => ({ ...c, brightness: v }))}
              />
              <SliderControl
                icon={<FiDroplet size={12} />}
                label="Contrast"
                value={colorCorrect.contrast}
                min={-0.5}
                max={0.5}
                onChange={(v) => setColorCorrect((c) => ({ ...c, contrast: v }))}
              />
              <SliderControl
                icon={<FiDroplet size={12} />}
                label="Saturation"
                value={colorCorrect.saturation}
                min={-0.5}
                max={0.5}
                onChange={(v) => setColorCorrect((c) => ({ ...c, saturation: v }))}
              />
              <SliderControl
                icon={<FiSun size={12} />}
                label="Warmth"
                value={colorCorrect.warmth}
                min={-0.3}
                max={0.3}
                onChange={(v) => setColorCorrect((c) => ({ ...c, warmth: v }))}
              />
              <button
                onClick={handleAutoColorCorrect}
                className="w-full rounded-lg bg-emerald-600 px-3 py-2 text-xs font-medium text-white hover:bg-emerald-500"
              >
                <FiCpu size={12} className="inline mr-1" />
                Auto Color Correct
              </button>
              <button
                onClick={() => setColorCorrect({ brightness: 0, contrast: 0, saturation: 0, warmth: 0 })}
                className="w-full rounded-lg bg-slate-800 px-3 py-2 text-xs text-slate-300 hover:bg-slate-700"
              >
                <FiRefreshCw size={12} className="inline mr-1" />
                Reset All
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SliderControl({
  icon,
  label,
  value,
  min,
  max,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="flex items-center gap-1 text-xs text-slate-400">{icon}{label}</span>
        <span className="text-xs text-slate-500">{(value * 100).toFixed(0)}%</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={0.01}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1 rounded-full bg-slate-800 appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-violet-500"
      />
    </div>
  );
}
