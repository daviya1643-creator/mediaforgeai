import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { useProjectStore } from '@/stores/projectStore';
import {
  ExportConfig, RESOLUTION_MAP, SOCIAL_PLATFORMS,
  generateExportFilename, calculateEstimatedSize,
  getOptimalSettingsForPlatform, simulateExport,
} from '@/utils/export';
import { cn } from '@/utils/cn';
import { FiDownload, FiShare2, FiCpu, FiCheck, FiCopy, FiExternalLink, FiClock } from 'react-icons/fi';

export default function ExportShare() {
  const { addNotification } = useAppStore();
  const { projects, currentProjectId, updateSettings } = useProjectStore();
  const currentProject = projects.find((p) => p.id === currentProjectId);

  const [config, setConfig] = useState<ExportConfig>({
    format: 'mp4',
    resolution: '1080p',
    quality: 'high',
    frameRate: 30,
    aspectRatio: '16:9',
    includeAudio: true,
    watermark: false,
  } as ExportConfig);

  const [exportProgress, setExportProgress] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const [activePlatform, setActivePlatform] = useState<string | null>(null);
  const [shareUrl, setShareUrl] = useState('');

  const estimatedSize = calculateEstimatedSize(config, 60);

  const handleExport = async () => {
    setIsExporting(true);
    setExportProgress(0);
    setExportComplete(false);

    await simulateExport(config, (pct) => setExportProgress(pct));

    setExportComplete(true);
    setIsExporting(false);
    const filename = generateExportFilename(currentProject?.name || 'project', config);
    addNotification({ message: `Export complete: ${filename}`, type: 'success' });

    if (currentProjectId) {
      updateSettings(currentProjectId, {
        resolution: config.resolution,
        frameRate: config.frameRate,
        format: config.format as 'mp4' | 'mov' | 'webm' | 'gif',
        quality: config.quality,
        aspectRatio: config.aspectRatio,
      });
    }
  };

  const handlePlatformShare = (platformId: string) => {
    setActivePlatform(platformId);
    const platform = SOCIAL_PLATFORMS.find((p) => p.id === platformId);
    if (platform) {
      const optimal = getOptimalSettingsForPlatform(platformId);
      setConfig((c) => ({ ...c, ...optimal }));
      addNotification({
        message: `Settings optimized for ${platform.name}`,
        type: 'info',
      });
    }
  };

  const handleCopyShareLink = () => {
    navigator.clipboard.writeText(shareUrl || window.location.href);
    addNotification({ message: 'Share link copied!', type: 'success' });
  };

  const handleShareWebAPI = async () => {
    try {
      await navigator.share({
        title: currentProject?.name || 'MediaForge AI Creation',
        text: 'Check out my creation from MediaForge AI!',
        url: window.location.href,
      });
    } catch {
      addNotification({ message: 'Web Share not supported on this browser', type: 'error' });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Export & Share</h1>
        <p className="text-sm text-slate-400 mt-1">
          Export in high resolution and share directly to social media platforms
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Export Settings */}
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <FiDownload size={14} className="text-emerald-400" />
              Export Settings
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-slate-400 block mb-1.5">Format</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['mp4', 'mov', 'webm', 'gif'] as const).map((fmt) => (
                    <button
                      key={fmt}
                      onClick={() => setConfig((c) => ({ ...c, format: fmt }))}
                      className={cn(
                        'rounded-lg px-3 py-2 text-sm font-medium transition-all',
                        config.format === fmt
                          ? 'bg-violet-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      )}
                    >
                      {fmt.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1.5">Resolution</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['720p', '1080p', '4K'] as const).map((res) => (
                    <button
                      key={res}
                      onClick={() => setConfig((c) => ({ ...c, resolution: res }))}
                      className={cn(
                        'rounded-lg px-3 py-2 text-sm font-medium transition-all',
                        config.resolution === res
                          ? 'bg-violet-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      )}
                    >
                      {res}
                      <span className="block text-[10px] opacity-70">
                        {RESOLUTION_MAP[res].width}x{RESOLUTION_MAP[res].height}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-400 block mb-1.5">Aspect Ratio</label>
                <div className="grid grid-cols-4 gap-2">
                  {(['16:9', '9:16', '1:1', '4:3'] as const).map((ratio) => (
                    <button
                      key={ratio}
                      onClick={() => setConfig((c) => ({ ...c, aspectRatio: ratio }))}
                      className={cn(
                        'rounded-lg px-2 py-2 text-xs font-medium transition-all',
                        config.aspectRatio === ratio
                          ? 'bg-violet-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      )}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-400 block mb-1.5">Frame Rate</label>
                  <select
                    value={config.frameRate}
                    onChange={(e) => setConfig((c) => ({ ...c, frameRate: parseInt(e.target.value) as 24 | 30 | 60 }))}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white"
                  >
                    <option value={24}>24 fps (Cinematic)</option>
                    <option value={30}>30 fps (Standard)</option>
                    <option value={60}>60 fps (Smooth)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1.5">Quality</label>
                  <select
                    value={config.quality}
                    onChange={(e) => setConfig((c) => ({ ...c, quality: e.target.value as ExportConfig['quality'] }))}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white"
                  >
                    <option value="low">Low (Fast)</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="lossless">Lossless</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.includeAudio}
                    onChange={(e) => setConfig((c) => ({ ...c, includeAudio: e.target.checked }))}
                    className="rounded border-slate-600 bg-slate-800 accent-violet-600"
                  />
                  Include Audio
                </label>
                <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.watermark}
                    onChange={(e) => setConfig((c) => ({ ...c, watermark: e.target.checked }))}
                    className="rounded border-slate-600 bg-slate-800 accent-violet-600"
                  />
                  Watermark
                </label>
              </div>

              <div className="rounded-lg bg-slate-800 p-3 flex items-center justify-between">
                <span className="text-xs text-slate-400">Estimated Size (60s)</span>
                <span className="text-sm text-white font-medium">{estimatedSize}</span>
              </div>

              {/* Export Progress */}
              {isExporting && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1"><FiCpu size={12} className="animate-spin" />Exporting...</span>
                    <span>{exportProgress.toFixed(0)}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 transition-all duration-300"
                      style={{ width: `${exportProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {exportComplete && (
                <div className="flex items-center gap-2 rounded-lg bg-emerald-600/20 px-3 py-2 text-sm text-emerald-400">
                  <FiCheck size={14} />
                  Export complete! File ready for download.
                </div>
              )}

              <button
                onClick={handleExport}
                disabled={isExporting}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-emerald-600 py-2.5 text-sm font-medium text-white hover:bg-emerald-500 disabled:opacity-50 transition-all"
              >
                <FiDownload size={14} />
                {isExporting ? 'Exporting...' : 'Export Now'}
              </button>
            </div>
          </div>
        </div>

        {/* Share Panel */}
        <div className="space-y-4">
          {/* Social Platforms */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <FiShare2 size={14} className="text-sky-400" />
              Share to Social Media
            </h3>
            <div className="space-y-2">
              {SOCIAL_PLATFORMS.map((platform) => (
                <button
                  key={platform.id}
                  onClick={() => handlePlatformShare(platform.id)}
                  className={cn(
                    'w-full flex items-center gap-3 rounded-lg p-3 transition-all text-left',
                    activePlatform === platform.id
                      ? 'border border-sky-600/50 bg-sky-600/10'
                      : 'border border-slate-800 bg-slate-800/50 hover:border-slate-700'
                  )}
                >
                  <span className="text-xl">{platform.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white">{platform.name}</p>
                    <p className="text-xs text-slate-500">
                      {platform.formats.join(', ').toUpperCase()} · Max {platform.maxDuration || '∞'}s · {platform.aspectRatios.join(', ')}
                    </p>
                  </div>
                  <span
                    className="rounded-full h-2.5 w-2.5"
                    style={{ backgroundColor: platform.color }}
                  />
                </button>
              ))}
            </div>

            {activePlatform && (
              <div className="mt-4 rounded-lg bg-sky-600/10 border border-sky-600/20 p-3">
                <p className="text-xs text-sky-400">
                  Settings optimized for {SOCIAL_PLATFORMS.find((p) => p.id === activePlatform)?.name}.
                  Export first, then share directly.
                </p>
              </div>
            )}
          </div>

          {/* Quick Share */}
          <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
            <h3 className="text-sm font-semibold text-white mb-4">Quick Share</h3>
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shareUrl}
                  onChange={(e) => setShareUrl(e.target.value)}
                  placeholder="Project share URL..."
                  className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
                />
                <button
                  onClick={handleCopyShareLink}
                  className="rounded-lg bg-slate-800 px-3 py-2 text-slate-400 hover:text-white"
                >
                  <FiCopy size={14} />
                </button>
              </div>
              <button
                onClick={handleShareWebAPI}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-sky-600 py-2.5 text-sm font-medium text-white hover:bg-sky-500"
              >
                <FiExternalLink size={14} />
                Share via Web Share API
              </button>
              <div className="grid grid-cols-2 gap-2">
                {activePlatform && (
                  <a
                    href={SOCIAL_PLATFORMS.find((p) => p.id === activePlatform)?.shareUrl() || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-1 rounded-lg py-2 text-xs font-medium text-white hover:opacity-90"
                    style={{ backgroundColor: SOCIAL_PLATFORMS.find((p) => p.id === activePlatform)?.color }}
                  >
                    <FiExternalLink size={12} />
                    Open {SOCIAL_PLATFORMS.find((p) => p.id === activePlatform)?.name}
                  </a>
                )}
                <button
                  onClick={() => addNotification({ message: 'Coming soon: Direct platform posting', type: 'info' })}
                  className="flex items-center justify-center gap-1 rounded-lg bg-slate-800 py-2 text-xs text-slate-400 hover:text-white"
                >
                  <FiClock size={12} />
                  Schedule Post
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
