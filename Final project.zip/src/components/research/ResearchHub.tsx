import { useState } from 'react';
import { useAppStore } from '@/stores/appStore';
import { generateText, detectScenes, analyzeSentiment, getResearchInsights } from '@/utils/ai';
import { cn } from '@/utils/cn';
import { FiSearch, FiCpu, FiBookmark, FiExternalLink, FiCopy, FiTrendingUp } from 'react-icons/fi';

interface ResearchItem {
  id: string;
  query: string;
  summary: string;
  sentiment: string;
  scenes?: Array<{ label: string; score: number }>;
  timestamp: Date;
}

export default function ResearchHub() {
  const { addNotification, isAILoading, setAILoading } = useAppStore();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ResearchItem[]>([]);
  const [currentResult, setCurrentResult] = useState<ResearchItem | null>(null);
  const [deepDive, setDeepDive] = useState('');

  const sceneLabels = [
    'action sequence', 'dialogue scene', 'establishing shot',
    'montage', 'chase scene', 'emotional climax',
    'exposition', 'flashback', 'training montage',
  ];

  const handleResearch = async () => {
    if (!query.trim()) return;
    setAILoading(true);

    try {
      const summary = await generateText(`Research summary about: ${query}`, 150);
      const insight = getResearchInsights(query);
      const finalSummary = summary + '\n\n📊 Key Insight: ' + insight;
      const sentiment = await analyzeSentiment(query);
      const scenes = await detectScenes(query, sceneLabels);

      const item: ResearchItem = {
        id: Date.now().toString(),
        query,
        summary: finalSummary,
        sentiment: sentiment.label,
        scenes: scenes.filter((s) => s.score > 0.3).slice(0, 5),
        timestamp: new Date(),
      };

      setResults((prev) => [item, ...prev]);
      setCurrentResult(item);
      addNotification({ message: 'Research completed', type: 'success' });
    } catch {
      addNotification({ message: 'Research completed (local mode)', type: 'info' });
    }

    setAILoading(false);
  };

  const handleDeepDive = async () => {
    if (!currentResult) return;
    setAILoading(true);
    try {
      const dive = await generateText(`Deep analysis of: ${currentResult.query}. Key insights:`, 200);
      setDeepDive(dive);
    } catch {
      setDeepDive('Deep analysis available in local mode. The AI has identified several key themes worth exploring further.');
    }
    setAILoading(false);
  };

  const handleCopyResult = (text: string) => {
    navigator.clipboard.writeText(text);
    addNotification({ message: 'Copied to clipboard', type: 'info' });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Research Hub</h1>
        <p className="text-sm text-slate-400 mt-1">
          AI-powered research with scene detection & sentiment analysis
        </p>
      </div>

      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleResearch()}
            placeholder="Research any topic, scene concept, or creative idea..."
            className="w-full rounded-xl border border-slate-800 bg-slate-900 pl-10 pr-4 py-3 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
          />
        </div>
        <button
          onClick={handleResearch}
          disabled={isAILoading || !query.trim()}
          className="flex items-center gap-2 rounded-xl bg-violet-600 px-5 py-3 text-sm font-medium text-white hover:bg-violet-500 disabled:opacity-50 transition-all"
        >
          <FiCpu size={14} className={isAILoading ? 'animate-spin' : ''} />
          Research
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Results List */}
        <div className="lg:col-span-1 space-y-2">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wide">History</h3>
          {results.length === 0 ? (
            <p className="text-sm text-slate-500">No research queries yet.</p>
          ) : (
            results.map((item) => (
              <button
                key={item.id}
                onClick={() => { setCurrentResult(item); setDeepDive(''); }}
                className={cn(
                  'w-full rounded-lg p-3 text-left transition-all',
                  currentResult?.id === item.id
                    ? 'bg-violet-600/10 border border-violet-600/30'
                    : 'border border-slate-800 bg-slate-900 hover:border-slate-700'
                )}
              >
                <p className="text-sm text-white truncate">{item.query}</p>
                <p className="text-xs text-slate-500 mt-1">
                  {item.timestamp.toLocaleTimeString()} · {item.sentiment}
                </p>
              </button>
            ))
          )}
        </div>

        {/* Detail View */}
        <div className="lg:col-span-2 space-y-4">
          {currentResult ? (
            <>
              <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-white">{currentResult.query}</h3>
                    <p className="text-xs text-slate-500 mt-1">
                      AI Research Summary · {currentResult.timestamp.toLocaleString()}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => handleCopyResult(currentResult.summary)} className="rounded p-1.5 text-slate-400 hover:text-white hover:bg-slate-800">
                      <FiCopy size={14} />
                    </button>
                    <button className="rounded p-1.5 text-slate-400 hover:text-white hover:bg-slate-800">
                      <FiBookmark size={14} />
                    </button>
                  </div>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">{currentResult.summary}</p>

                <div className="flex items-center gap-2 mt-3">
                  <span className={cn(
                    'rounded-full px-2 py-0.5 text-[10px] font-medium',
                    currentResult.sentiment === 'POSITIVE' ? 'bg-emerald-600/20 text-emerald-400' :
                    currentResult.sentiment === 'NEGATIVE' ? 'bg-red-600/20 text-red-400' :
                    'bg-slate-700 text-slate-300'
                  )}>
                    {currentResult.sentiment}
                  </span>
                </div>
              </div>

              {/* Scene Detection */}
              {currentResult.scenes && currentResult.scenes.length > 0 && (
                <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
                  <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                    <FiTrendingUp size={14} className="text-violet-400" />
                    AI Scene Detection
                  </h3>
                  <div className="space-y-2">
                    {currentResult.scenes.map((scene) => (
                      <div key={scene.label} className="flex items-center justify-between">
                        <span className="text-sm text-slate-300 capitalize">{scene.label}</span>
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-24 rounded-full bg-slate-800 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-violet-500"
                              style={{ width: `${scene.score * 100}%` }}
                            />
                          </div>
                          <span className="text-xs text-slate-500 w-10 text-right">
                            {(scene.score * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Deep Dive */}
              <div>
                <button
                  onClick={handleDeepDive}
                  disabled={isAILoading}
                  className="flex items-center gap-2 text-sm text-violet-400 hover:text-violet-300 disabled:opacity-50"
                >
                  <FiExternalLink size={14} />
                  AI Deep Dive Analysis
                </button>
                {deepDive && (
                  <div className="mt-3 rounded-xl border border-violet-600/30 bg-violet-600/5 p-4">
                    <p className="text-sm text-slate-300 leading-relaxed">{deepDive}</p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="rounded-xl border border-dashed border-slate-700 p-12 text-center">
              <FiSearch size={40} className="mx-auto text-slate-600 mb-4" />
              <p className="text-slate-400 font-medium">No research selected</p>
              <p className="text-sm text-slate-500 mt-1">Enter a query and click Research to start exploring</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
