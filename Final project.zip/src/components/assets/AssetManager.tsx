import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useAppStore } from '@/stores/appStore';
import { useAssetStore, type Asset } from '@/stores/assetStore';
import { cn } from '@/utils/cn';
import { FiUpload, FiGrid, FiList, FiSearch, FiTrash2, FiDownload, FiTag, FiHardDrive } from 'react-icons/fi';

export default function AssetManager() {
  const { addNotification } = useAppStore();
  const {
    assets, selectedAssets, addAsset, removeAsset, selectAsset,
    selectAll, clearSelection, searchQuery, setSearchQuery,
    filterType, setFilterType, sortBy, setSortBy, viewMode, setViewMode,
  } = useAssetStore();

  const [showUpload, setShowUpload] = useState(false);
  const [tagInput, setTagInput] = useState('');
  const [taggingAsset, setTaggingAsset] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach((file) => {
      const type = file.type.startsWith('video/') ? 'video'
        : file.type.startsWith('audio/') ? 'audio'
        : file.type.startsWith('image/') ? 'image'
        : 'document';

      addAsset({
        id: `asset_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name: file.name,
        type,
        size: file.size,
        url: URL.createObjectURL(file),
        createdAt: new Date(),
        tags: [],
      });
    });
    addNotification({ message: `Added ${acceptedFiles.length} asset(s)`, type: 'success' });
  }, [addAsset, addNotification]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    noClick: true,
  });

  const filteredAssets = assets
    .filter((a) => filterType === 'all' || a.type === filterType)
    .filter((a) => !searchQuery || a.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      switch (sortBy) {
        case 'name': return a.name.localeCompare(b.name);
        case 'date': return b.createdAt.getTime() - a.createdAt.getTime();
        case 'size': return b.size - a.size;
        case 'type': return a.type.localeCompare(b.type);
        default: return 0;
      }
    });

  const totalSize = assets.reduce((acc, a) => acc + a.size, 0);
  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  };

  const handleAddTag = (assetId: string) => {
    if (!tagInput.trim()) return;
    const asset = assets.find((a) => a.id === assetId);
    if (asset) {
      useAssetStore.getState().updateAsset(assetId, {
        tags: [...asset.tags, tagInput.trim()],
      });
    }
    setTagInput('');
    setTaggingAsset(null);
  };

  const handleRemoveTag = (assetId: string, tag: string) => {
    const asset = assets.find((a) => a.id === assetId);
    if (asset) {
      useAssetStore.getState().updateAsset(assetId, {
        tags: asset.tags.filter((t) => t !== tag),
      });
    }
  };

  const handleDownload = (asset: Asset) => {
    const a = document.createElement('a');
    a.href = asset.url;
    a.download = asset.name;
    a.click();
  };

  const typeIcons: Record<string, string> = {
    image: '🖼️',
    video: '🎬',
    audio: '🎵',
    document: '📄',
    project: '📁',
  };

  return (
    <div className="p-6 space-y-6" {...getRootProps()}>
      <input {...getInputProps()} />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Asset Manager</h1>
          <p className="text-sm text-slate-400 mt-1">
            {assets.length} assets · {formatSize(totalSize)} total
          </p>
        </div>
        <button
          onClick={() => setShowUpload(true)}
          className="flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2 text-sm font-medium text-white hover:bg-violet-500"
        >
          <FiUpload size={14} />
          Upload
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search assets..."
            className="w-full rounded-lg border border-slate-800 bg-slate-900 pl-10 pr-4 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as Asset['type'] | 'all')}
          className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-sm text-white"
        >
          <option value="all">All Types</option>
          <option value="image">Images</option>
          <option value="video">Videos</option>
          <option value="audio">Audio</option>
          <option value="document">Documents</option>
        </select>
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
          className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-sm text-white"
        >
          <option value="date">Newest</option>
          <option value="name">Name</option>
          <option value="size">Size</option>
          <option value="type">Type</option>
        </select>
        <div className="flex rounded-lg border border-slate-800 overflow-hidden">
          <button
            onClick={() => setViewMode('grid')}
            className={cn('p-2', viewMode === 'grid' ? 'bg-violet-600 text-white' : 'bg-slate-900 text-slate-400')}
          >
            <FiGrid size={14} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={cn('p-2', viewMode === 'list' ? 'bg-violet-600 text-white' : 'bg-slate-900 text-slate-400')}
          >
            <FiList size={14} />
          </button>
        </div>
        {selectedAssets.length > 0 && (
          <>
            <button onClick={selectAll} className="text-xs text-violet-400 hover:text-violet-300">Select All</button>
            <button onClick={clearSelection} className="text-xs text-slate-400 hover:text-white">Clear</button>
            <button
              onClick={() => selectedAssets.forEach((id) => removeAsset(id))}
              className="flex items-center gap-1 rounded bg-red-600/20 px-3 py-1.5 text-xs text-red-400 hover:bg-red-600/30"
            >
              <FiTrash2 size={12} /> Delete ({selectedAssets.length})
            </button>
          </>
        )}
      </div>

      {/* Assets Grid */}
      {filteredAssets.length === 0 ? (
        <div className={cn(
          'rounded-xl border-2 border-dashed p-16 text-center transition-all',
          isDragActive ? 'border-violet-500 bg-violet-600/10' : 'border-slate-700 bg-slate-900'
        )}>
          <FiHardDrive size={48} className="mx-auto text-slate-600 mb-4" />
          <p className="text-slate-400 font-medium">
            {isDragActive ? 'Drop files here...' : 'No assets yet'}
          </p>
          <p className="text-sm text-slate-500 mt-1">
            Drag & drop files or click Upload to add media
          </p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          {filteredAssets.map((asset) => (
            <div
              key={asset.id}
              onClick={() => selectAsset(asset.id)}
              className={cn(
                'rounded-xl border p-3 cursor-pointer transition-all',
                selectedAssets.includes(asset.id)
                  ? 'border-violet-500 bg-violet-600/10'
                  : 'border-slate-800 bg-slate-900 hover:border-slate-700'
              )}
            >
              <div className="h-24 rounded-lg bg-slate-800 flex items-center justify-center text-3xl mb-2">
                {asset.type === 'image' && asset.url ? (
                  <img src={asset.url} alt="" className="h-full w-full object-cover rounded-lg" />
                ) : (
                  typeIcons[asset.type] || '📁'
                )}
              </div>
              <p className="text-xs text-white truncate font-medium">{asset.name}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-[10px] text-slate-500">{formatSize(asset.size)}</span>
                <span className="text-[10px] text-slate-600">{asset.type}</span>
              </div>
              {asset.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {asset.tags.map((tag) => (
                    <span key={tag} className="rounded bg-slate-800 px-1.5 py-0.5 text-[9px] text-slate-400">{tag}</span>
                  ))}
                </div>
              )}
              <div className="flex gap-1 mt-2">
                <button
                  onClick={(e) => { e.stopPropagation(); handleDownload(asset); }}
                  className="flex-1 rounded bg-slate-800 py-1 text-[10px] text-slate-400 hover:text-white"
                >
                  <FiDownload size={10} className="inline mr-0.5" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setTaggingAsset(asset.id); }}
                  className="flex-1 rounded bg-slate-800 py-1 text-[10px] text-slate-400 hover:text-white"
                >
                  <FiTag size={10} className="inline mr-0.5" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); removeAsset(asset.id); }}
                  className="flex-1 rounded bg-slate-800 py-1 text-[10px] text-slate-400 hover:text-red-400"
                >
                  <FiTrash2 size={10} className="inline" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-1">
          {filteredAssets.map((asset) => (
            <div
              key={asset.id}
              onClick={() => selectAsset(asset.id)}
              className={cn(
                'flex items-center gap-3 rounded-lg p-3 cursor-pointer transition-all',
                selectedAssets.includes(asset.id)
                  ? 'border border-violet-500 bg-violet-600/10'
                  : 'border border-slate-800 bg-slate-900 hover:border-slate-700'
              )}
            >
              <span className="text-2xl">{typeIcons[asset.type]}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white truncate">{asset.name}</p>
                <p className="text-xs text-slate-500">{formatSize(asset.size)} · {asset.type} · {asset.createdAt.toLocaleDateString()}</p>
              </div>
              {asset.tags.map((tag) => (
                <span key={tag} className="rounded bg-slate-800 px-2 py-0.5 text-xs text-slate-400">{tag}</span>
              ))}
              <button onClick={(e) => { e.stopPropagation(); removeAsset(asset.id); }} className="text-slate-600 hover:text-red-400">
                <FiTrash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Tag Modal */}
      {taggingAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setTaggingAsset(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-900 p-5 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-sm font-semibold text-white mb-3">Add Tag</h3>
            <div className="flex gap-2">
              <input
                autoFocus
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddTag(taggingAsset)}
                placeholder="Tag name..."
                className="flex-1 rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-500"
              />
              <button onClick={() => handleAddTag(taggingAsset)} className="rounded-lg bg-violet-600 px-3 py-2 text-sm text-white">Add</button>
            </div>
            {(() => {
              const asset = assets.find((a) => a.id === taggingAsset);
              return asset && asset.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3">
                  {asset.tags.map((tag) => (
                    <span key={tag} className="flex items-center gap-1 rounded-full bg-slate-800 px-2 py-0.5 text-xs text-slate-300">
                      {tag}
                      <button onClick={() => handleRemoveTag(taggingAsset, tag)} className="text-slate-500 hover:text-red-400">×</button>
                    </span>
                  ))}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* Upload Modal */}
      {showUpload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" onClick={() => setShowUpload(false)}>
          <div
            className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            {...getRootProps()}
          >
            <input {...getInputProps()} />
            <div className={cn(
              'rounded-xl border-2 border-dashed p-12 text-center transition-all',
              isDragActive ? 'border-violet-500 bg-violet-600/10' : 'border-slate-700'
            )}>
              <FiUpload size={48} className="mx-auto text-slate-500 mb-4" />
              <p className="text-slate-300 font-medium">Drop files here</p>
              <p className="text-sm text-slate-500 mt-1">or click to browse</p>
            </div>
            <button
              onClick={() => setShowUpload(false)}
              className="w-full mt-3 rounded-lg bg-slate-800 py-2 text-sm text-slate-400 hover:text-white"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
