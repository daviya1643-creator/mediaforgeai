import { create } from 'zustand';

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: Date;
  updatedAt: Date;
  type: 'video' | 'image' | 'script' | 'mixed';
  status: 'draft' | 'in-progress' | 'review' | 'completed';
  scripts: ScriptItem[];
  mediaAssets: string[];
  timeline: TimelineClip[];
  settings: ProjectSettings;
}

export interface ScriptItem {
  id: string;
  content: string;
  type: 'scene' | 'dialogue' | 'action' | 'note';
  order: number;
  aiGenerated?: boolean;
}

export interface TimelineClip {
  id: string;
  assetId: string;
  startTime: number;
  duration: number;
  trimStart: number;
  trimEnd: number;
  effects: VideoEffect[];
}

export interface VideoEffect {
  type: 'color-correction' | 'style-transfer' | 'transition' | 'text-overlay' | 'filter';
  params: Record<string, number | string>;
}

export interface ProjectSettings {
  resolution: '1080p' | '4K' | '720p';
  frameRate: 24 | 30 | 60;
  format: 'mp4' | 'mov' | 'webm' | 'gif';
  quality: 'low' | 'medium' | 'high' | 'lossless';
  aspectRatio: '16:9' | '9:16' | '1:1' | '4:3';
}

interface ProjectState {
  projects: Project[];
  currentProjectId: string | null;
  createProject: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteProject: (id: string) => void;
  setCurrentProject: (id: string) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  addScriptItem: (projectId: string, item: Omit<ScriptItem, 'id'>) => void;
  updateScriptItem: (projectId: string, itemId: string, content: string) => void;
  removeScriptItem: (projectId: string, itemId: string) => void;
  addTimelineClip: (projectId: string, clip: Omit<TimelineClip, 'id'>) => void;
  updateTimelineClip: (projectId: string, clipId: string, updates: Partial<TimelineClip>) => void;
  removeTimelineClip: (projectId: string, clipId: string) => void;
  updateSettings: (projectId: string, settings: Partial<ProjectSettings>) => void;
}

let idCounter = 0;
const genId = () => `proj_${Date.now()}_${++idCounter}`;
const genScriptId = () => `scr_${Date.now()}_${++idCounter}`;
const genClipId = () => `clip_${Date.now()}_${++idCounter}`;

export const useProjectStore = create<ProjectState>((set) => ({
  projects: [],
  currentProjectId: null,
  createProject: (project) => {
    const id = genId();
    set((s) => ({
      projects: [
        ...s.projects,
        { ...project, id, createdAt: new Date(), updatedAt: new Date() },
      ],
      currentProjectId: id,
    }));
  },
  deleteProject: (id) =>
    set((s) => ({
      projects: s.projects.filter((p) => p.id !== id),
      currentProjectId: s.currentProjectId === id ? null : s.currentProjectId,
    })),
  setCurrentProject: (id) => set({ currentProjectId: id }),
  updateProject: (id, updates) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date() } : p
      ),
    })),
  addScriptItem: (projectId, item) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? { ...p, scripts: [...p.scripts, { ...item, id: genScriptId() }], updatedAt: new Date() }
          : p
      ),
    })),
  updateScriptItem: (projectId, itemId, content) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              scripts: p.scripts.map((si) =>
                si.id === itemId ? { ...si, content } : si
              ),
              updatedAt: new Date(),
            }
          : p
      ),
    })),
  removeScriptItem: (projectId, itemId) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              scripts: p.scripts.filter((si) => si.id !== itemId),
              updatedAt: new Date(),
            }
          : p
      ),
    })),
  addTimelineClip: (projectId, clip) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              timeline: [...p.timeline, { ...clip, id: genClipId() }],
              updatedAt: new Date(),
            }
          : p
      ),
    })),
  updateTimelineClip: (projectId, clipId, updates) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              timeline: p.timeline.map((c) =>
                c.id === clipId ? { ...c, ...updates } : c
              ),
              updatedAt: new Date(),
            }
          : p
      ),
    })),
  removeTimelineClip: (projectId, clipId) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              timeline: p.timeline.filter((c) => c.id !== clipId),
              updatedAt: new Date(),
            }
          : p
      ),
    })),
  updateSettings: (projectId, settings) =>
    set((s) => ({
      projects: s.projects.map((p) =>
        p.id === projectId
          ? {
              ...p,
              settings: { ...p.settings, ...settings },
              updatedAt: new Date(),
            }
          : p
      ),
    })),
}));
