import { create } from 'zustand';

export interface Asset {
  id: string;
  name: string;
  type: 'image' | 'video' | 'audio' | 'document' | 'project';
  size: number;
  url: string;
  thumbnail?: string;
  createdAt: Date;
  tags: string[];
  metadata?: Record<string, unknown>;
  duration?: number;
  resolution?: string;
  codec?: string;
}

interface AssetState {
  assets: Asset[];
  selectedAssets: string[];
  addAsset: (asset: Asset) => void;
  removeAsset: (id: string) => void;
  updateAsset: (id: string, updates: Partial<Asset>) => void;
  selectAsset: (id: string) => void;
  deselectAsset: (id: string) => void;
  selectAll: () => void;
  clearSelection: () => void;
  filterType: Asset['type'] | 'all';
  setFilterType: (type: Asset['type'] | 'all') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  sortBy: 'name' | 'date' | 'size' | 'type';
  setSortBy: (sort: 'name' | 'date' | 'size' | 'type') => void;
  viewMode: 'grid' | 'list';
  setViewMode: (mode: 'grid' | 'list') => void;
}

export const useAssetStore = create<AssetState>((set) => ({
  assets: [],
  selectedAssets: [],
  addAsset: (asset) => set((s) => ({ assets: [...s.assets, asset] })),
  removeAsset: (id) =>
    set((s) => ({
      assets: s.assets.filter((a) => a.id !== id),
      selectedAssets: s.selectedAssets.filter((sid) => sid !== id),
    })),
  updateAsset: (id, updates) =>
    set((s) => ({
      assets: s.assets.map((a) => (a.id === id ? { ...a, ...updates } : a)),
    })),
  selectAsset: (id) =>
    set((s) => ({
      selectedAssets: s.selectedAssets.includes(id)
        ? s.selectedAssets.filter((sid) => sid !== id)
        : [...s.selectedAssets, id],
    })),
  deselectAsset: (id) =>
    set((s) => ({ selectedAssets: s.selectedAssets.filter((sid) => sid !== id) })),
  selectAll: () =>
    set((s) => ({ selectedAssets: s.assets.map((a) => a.id) })),
  clearSelection: () => set({ selectedAssets: [] }),
  filterType: 'all',
  setFilterType: (filterType) => set({ filterType }),
  searchQuery: '',
  setSearchQuery: (searchQuery) => set({ searchQuery }),
  sortBy: 'date',
  setSortBy: (sortBy) => set({ sortBy }),
  viewMode: 'grid',
  setViewMode: (viewMode) => set({ viewMode }),
}));
