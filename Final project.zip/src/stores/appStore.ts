import { create } from 'zustand';

export type WorkspaceTab =
  | 'dashboard'
  | 'scriptwriter'
  | 'research'
  | 'media'
  | 'video-editor'
  | 'analysis'
  | 'assets'
  | 'export'
  | 'collaboration';

export type AIModel = 'image-gen' | 'text-gen' | 'analysis' | 'style-transfer';

interface ProcessingTask {
  id: string;
  type: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  message: string;
}

interface AppState {
  activeTab: WorkspaceTab;
  setActiveTab: (tab: WorkspaceTab) => void;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  processingQueue: ProcessingTask[];
  addTask: (task: ProcessingTask) => void;
  updateTask: (id: string, updates: Partial<ProcessingTask>) => void;
  removeTask: (id: string) => void;
  isAILoading: boolean;
  setAILoading: (loading: boolean) => void;
  aiModel: AIModel;
  setAIModel: (model: AIModel) => void;
  notifications: { id: string; message: string; type: 'success' | 'error' | 'info' }[];
  addNotification: (notification: { message: string; type: 'success' | 'error' | 'info' }) => void;
  removeNotification: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  activeTab: 'dashboard',
  setActiveTab: (tab) => set({ activeTab: tab }),
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  darkMode: true,
  toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),
  processingQueue: [],
  addTask: (task) => set((s) => ({ processingQueue: [...s.processingQueue, task] })),
  updateTask: (id, updates) =>
    set((s) => ({
      processingQueue: s.processingQueue.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    })),
  removeTask: (id) =>
    set((s) => ({ processingQueue: s.processingQueue.filter((t) => t.id !== id) })),
  isAILoading: false,
  setAILoading: (loading) => set({ isAILoading: loading }),
  aiModel: 'text-gen',
  setAIModel: (model) => set({ aiModel: model }),
  notifications: [],
  addNotification: (notification) =>
    set((s) => ({
      notifications: [
        ...s.notifications,
        { ...notification, id: Date.now().toString() },
      ],
    })),
  removeNotification: (id) =>
    set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) })),
}));
