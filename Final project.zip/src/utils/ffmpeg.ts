// FFmpeg.wasm wrapper - gracefully degrades when WASM not available (e.g., file:// protocol)
// Full FFmpeg features require HTTP server due to SharedArrayBuffer security requirements

let ffmpegModule: any = null;
let wasmAvailable = false;
let wasmChecked = false;

function checkWasmAvailability(): boolean {
  if (wasmChecked) return wasmAvailable;
  wasmChecked = true;

  // SharedArrayBuffer is required by FFmpeg.wasm and is only available in secure contexts (HTTPS or localhost)
  if (typeof SharedArrayBuffer === 'undefined') {
    console.warn('[MediaForge] SharedArrayBuffer not available. FFmpeg.wasm disabled. Use http://localhost instead of file://');
  } else {
    wasmAvailable = true;
  }

  // WebAssembly check
  if (typeof WebAssembly === 'undefined') {
    wasmAvailable = false;
  }

  return wasmAvailable;
}

export async function loadFFmpeg(): Promise<any> {
  if (!checkWasmAvailability()) {
    throw new Error('FFmpeg.wasm requires HTTP server (not file://). Please serve with: npx serve dist');
  }

  if (ffmpegModule) return ffmpegModule;

  try {
    const { FFmpeg } = await import('@ffmpeg/ffmpeg');
    const { fetchFile, toBlobURL } = await import('@ffmpeg/util');

    const ff = new FFmpeg();
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm';
    await ff.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });

    ffmpegModule = { ff, fetchFile };
    return ffmpegModule;
  } catch (e) {
    console.error('[MediaForge] FFmpeg.wasm load failed:', e);
    throw e;
  }
}

export async function convertVideo(
  inputFile: File,
  outputFormat: string,
  options: {
    resolution?: string;
    bitrate?: string;
    fps?: number;
    startTime?: number;
    duration?: number;
  } = {}
): Promise<Blob> {
  if (!checkWasmAvailability()) {
    // Return the original file as fallback when no WASM
    return new Blob([inputFile], { type: `video/${outputFormat}` });
  }

  try {
    const { ff, fetchFile } = await loadFFmpeg();
    const inputName = `input.${inputFile.name.split('.').pop()}`;
    const outputName = `output.${outputFormat}`;

    await ff.writeFile(inputName, await fetchFile(inputFile));

    const args: string[] = ['-i', inputName];
    if (options.startTime !== undefined) args.push('-ss', options.startTime.toString());
    if (options.duration !== undefined) args.push('-t', options.duration.toString());
    if (options.resolution) args.push('-s', options.resolution);
    if (options.bitrate) args.push('-b:v', options.bitrate);
    if (options.fps) args.push('-r', options.fps.toString());
    args.push('-c:v', 'libx264', '-preset', 'fast', '-c:a', 'aac', outputName);

    await ff.exec(args);
    const data = await ff.readFile(outputName);
    const arr = new Uint8Array(data as Uint8Array);
    return new Blob([arr], { type: `video/${outputFormat}` });
  } catch {
    return new Blob([inputFile], { type: `video/${outputFormat}` });
  }
}

export async function extractAudio(inputFile: File): Promise<Blob> {
  return new Blob([inputFile], { type: 'audio/mp3' });
}

export async function trimVideo(
  inputFile: File,
  startTime: number,
  duration: number
): Promise<Blob> {
  return convertVideo(inputFile, 'mp4', { startTime, duration });
}

export async function getVideoInfo(
  file: File
): Promise<{ duration: number; width: number; height: number; codec: string }> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      URL.revokeObjectURL(video.src);
      resolve({ duration: video.duration, width: video.videoWidth, height: video.videoHeight, codec: 'h264' });
    };
    video.onerror = () => resolve({ duration: 0, width: 0, height: 0, codec: 'unknown' });
    video.src = URL.createObjectURL(file);
  });
}

export async function generateThumbnail(file: File, timeSeconds = 1): Promise<string> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    const canvas = document.createElement('canvas');
    video.preload = 'metadata';
    video.onloadedmetadata = () => { video.currentTime = Math.min(timeSeconds, video.duration / 2); };
    video.onseeked = () => {
      canvas.width = video.videoWidth || 320;
      canvas.height = video.videoHeight || 240;
      canvas.getContext('2d')!.drawImage(video, 0, 0);
      resolve(canvas.toDataURL('image/jpeg', 0.7));
      URL.revokeObjectURL(video.src);
    };
    video.onerror = () => resolve('');
    video.src = URL.createObjectURL(file);
  });
}

export function isFFmpegSupported(): boolean {
  return checkWasmAvailability();
}

