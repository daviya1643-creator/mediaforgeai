import type { Asset } from '@/stores/assetStore';
import type { Project, TimelineClip } from '@/stores/projectStore';

const RATE_XML = (frameRate: number) =>
  `<rate><timebase>${frameRate}</timebase><ntsc>FALSE</ntsc></rate>`;

function xmlEscape(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function toFrames(seconds: number, frameRate: number): number {
  return Math.max(0, Math.round(seconds * frameRate));
}

function safeMediaName(name: string): string {
  const leaf = name.split(/[\\/]/).pop() || 'media';
  return encodeURIComponent(leaf).replace(/%2F/gi, '_');
}

function mediaUrl(asset: Asset | undefined, name: string): string {
  if (asset?.url?.startsWith('file://')) return asset.url;
  // Browser blob: and data: URLs cannot be opened by Premiere. The user can relink
  // these offline entries to the original files after importing the XML.
  return `file:///C:/MediaForgeAI-Relink/${safeMediaName(name)}`;
}

function sampleCharacteristics(width: number, height: number, frameRate: number): string {
  return `<samplecharacteristics><width>${width}</width><height>${height}</height><pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance>${RATE_XML(frameRate)}</samplecharacteristics>`;
}

function fileXml(
  fileId: string,
  asset: Asset | undefined,
  name: string,
  kind: 'video' | 'image' | 'audio',
  sourceFrames: number,
  width: number,
  height: number,
  frameRate: number,
): string {
  const escapedName = xmlEscape(name);
  const uri = xmlEscape(mediaUrl(asset, name));
  const audioChannels = Number(asset?.metadata?.audioChannels) || 2;
  const audioSampleRate = Number(asset?.metadata?.audioSampleRate) || 48000;
  const videoInfo = kind === 'audio' ? '' : `<video>${sampleCharacteristics(width, height, frameRate)}</video>`;
  const hasAudio = kind === 'audio' || (kind === 'video' && asset?.metadata?.hasAudio !== false);
  const audioInfo = hasAudio
    ? `<audio><channelcount>${audioChannels}</channelcount><samplecharacteristics><depth>16</depth><samplerate>${audioSampleRate}</samplerate></samplecharacteristics></audio>`
    : '';
  return `<file id="${fileId}"><name>${escapedName}</name><pathurl>${uri}</pathurl>${RATE_XML(frameRate)}<duration>${sourceFrames}</duration><media>${videoInfo}${audioInfo}</media></file>`;
}

function clipItemXml(
  id: string,
  name: string,
  file: string,
  mediaType: 'video' | 'audio',
  frameRate: number,
  sourceIn: number,
  duration: number,
  timelineStart: number,
): string {
  const timelineEnd = timelineStart + duration;
  return `<clipitem id="${id}"><name>${xmlEscape(name)}</name><enabled>TRUE</enabled><duration>${duration}</duration>${RATE_XML(frameRate)}<start>${timelineStart}</start><end>${timelineEnd}</end><in>${sourceIn}</in><out>${sourceIn + duration}</out>${file}<sourcetrack><mediatype>${mediaType}</mediatype><trackindex>1</trackindex></sourcetrack></clipitem>`;
}

function resolveAsset(clip: TimelineClip, assets: Asset[]): Asset | undefined {
  return assets.find((asset) => asset.id === clip.assetId || asset.name === clip.assetId);
}

/** Build a Final Cut Pro 7 XML interchange sequence that Premiere Pro can import. */
export function generatePremiereXml(
  project: Project,
  assets: Asset[],
  includeAudio = true,
): string {
  const timeline = project.timeline || [];
  if (timeline.length === 0) {
    throw new Error('Add at least one clip to the project timeline before exporting.');
  }

  const frameRate = project.settings?.frameRate || 30;
  const ratioSizes: Record<string, [number, number]> = {
    '16:9': [1920, 1080],
    '9:16': [1080, 1920],
    '1:1': [1080, 1080],
    '4:3': [1440, 1080],
  };
  const [baseWidth, baseHeight] = ratioSizes[project.settings?.aspectRatio || '16:9'] || ratioSizes['16:9'];
  const scale = project.settings?.resolution === '4K' ? 2 : project.settings?.resolution === '720p' ? 2 / 3 : 1;
  const width = Math.round(baseWidth * scale);
  const height = Math.round(baseHeight * scale);

  const videoItems: string[] = [];
  const audioItems: string[] = [];
  let cursorFrame = 0;

  timeline.forEach((clip, index) => {
    const asset = resolveAsset(clip, assets);
    const name = asset?.name || clip.assetId || `media-${index + 1}`;
    if (asset && asset.type !== 'video' && asset.type !== 'image' && asset.type !== 'audio') {
      throw new Error(`Timeline media "${name}" is not a video, image, or audio asset.`);
    }
    const kind: 'video' | 'image' | 'audio' = asset?.type === 'image'
      ? 'image'
      : asset?.type === 'audio'
        ? 'audio'
        : 'video';
    const clipSeconds = Math.max(1 / frameRate, Number(clip.duration) || 0);
    const durationFrames = Math.max(1, toFrames(clipSeconds, frameRate));
    const sourceIn = toFrames(Math.max(0, Number(clip.trimStart) || 0), frameRate);
    const sourceFrames = Math.max(
      sourceIn + durationFrames,
      toFrames(asset?.duration || clipSeconds + (Number(clip.trimStart) || 0), frameRate),
    );
    const fileId = `media_${index + 1}`;
    const videoFile = fileXml(fileId, asset, name, kind, sourceFrames, width, height, frameRate);
    const audioFile = fileXml(`${fileId}_audio`, asset, name, kind, sourceFrames, width, height, frameRate);

    if (kind !== 'audio') {
      videoItems.push(
        clipItemXml(`video_clip_${index + 1}`, name, videoFile, 'video', frameRate, sourceIn, durationFrames, cursorFrame),
      );
    }
    if (includeAudio && (kind === 'audio' || (kind === 'video' && asset?.metadata?.hasAudio !== false))) {
      audioItems.push(
        clipItemXml(`audio_clip_${index + 1}`, `${name} — audio`, audioFile, 'audio', frameRate, sourceIn, durationFrames, cursorFrame),
      );
    }
    cursorFrame += durationFrames;
  });

  const videoTrack = `<track>${videoItems.join('')}<enabled>TRUE</enabled><locked>FALSE</locked></track>`;
  const audioTrack = `<track>${audioItems.join('')}<enabled>TRUE</enabled><locked>FALSE</locked></track>`;
  const sequenceName = xmlEscape(`${project.name} — Premiere Pro`);
  const projectName = xmlEscape(project.name || 'MediaForge AI Project');

  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xmeml>
<xmeml version="5"><project id="project_1"><name>${projectName}</name><children><sequence id="sequence_1"><name>${sequenceName}</name><duration>${cursorFrame}</duration>${RATE_XML(frameRate)}<timecode>${RATE_XML(frameRate)}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode><media><video><format>${sampleCharacteristics(width, height, frameRate)}</format>${videoTrack}</video><audio><numOutputChannels>2</numOutputChannels><format><samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics></format>${audioTrack}</audio></media></sequence></children></project></xmeml>`;
}
