import type { WorkspaceTab } from '@/stores/appStore';

export interface WorkflowStep {
  id: string;
  tab: WorkspaceTab;
  title: string;
  description: string;
  emoji: string;
  required: boolean;
  estimatedTime: string;
  tips: string[];
  completionCriteria: string;
}

export interface WorkflowProgress {
  stepId: string;
  completed: boolean;
  completedAt?: number;
  notes?: string;
}

export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    id: 'plan',
    tab: 'dashboard',
    title: 'Project Planning',
    description: 'Create your project, define goals, and set up your workspace',
    emoji: '🎯',
    required: true,
    estimatedTime: '2-5 min',
    tips: [
      'Choose a clear project name related to your content',
      'Decide on target platforms (Instagram, TikTok, YouTube)',
      'Note your target aspect ratio for export',
    ],
    completionCriteria: 'Project created with name and target platform selected',
  },
  {
    id: 'script',
    tab: 'scriptwriter',
    title: 'Script Writing',
    description: 'Generate or write your script, scene by scene',
    emoji: '📝',
    required: true,
    estimatedTime: '5-15 min',
    tips: [
      'Use AI generation for quick first drafts',
      'Add scene types (dialogue, action, note) for organization',
      'Review AI sentiment analysis to match your tone',
    ],
    completionCriteria: 'At least 1 scene added to the script editor',
  },
  {
    id: 'research',
    tab: 'research',
    title: 'Research & Insights',
    description: 'Research topics, detect scenes, analyze sentiment',
    emoji: '🔍',
    required: false,
    estimatedTime: '3-10 min',
    tips: [
      'Research your topic for deeper AI insights',
      'Use scene detection to plan visual sequences',
      'Save interesting findings as notes',
    ],
    completionCriteria: 'At least 1 research query completed',
  },
  {
    id: 'media',
    tab: 'media',
    title: 'Media Creation',
    description: 'Upload or generate images/videos, apply styles and effects',
    emoji: '🎨',
    required: true,
    estimatedTime: '10-30 min',
    tips: [
      'Upload all your raw footage and images',
      'Apply style transfer for consistent look',
      'Use AI color correction for professional grading',
    ],
    completionCriteria: 'At least 1 media asset uploaded with style applied',
  },
  {
    id: 'edit',
    tab: 'video-editor',
    title: 'Video Editing',
    description: 'Trim, arrange timeline, add clips, and prepare for export',
    emoji: '✂️',
    required: true,
    estimatedTime: '15-45 min',
    tips: [
      'Use FFmpeg.wasm for real video processing',
      'Add clips to timeline in sequence',
      'Preview trims before adding to project',
    ],
    completionCriteria: 'At least 1 clip in the timeline',
  },
  {
    id: 'analyze',
    tab: 'analysis',
    title: 'AI Quality Check',
    description: 'Run AI analysis on your content for quality assurance',
    emoji: '🤖',
    required: false,
    estimatedTime: '3-5 min',
    tips: [
      'Check sentiment matches your intended tone',
      'Run scene detection for narrative flow',
      'Review auto-edit suggestions',
    ],
    completionCriteria: 'AI analysis run on script or media',
  },
  {
    id: 'export',
    tab: 'export',
    title: 'Export & Share',
    description: 'Export in high quality and share to social platforms',
    emoji: '🚀',
    required: true,
    estimatedTime: '2-10 min',
    tips: [
      'Choose resolution based on target platform',
      'Use platform presets for optimal settings',
      'Export lossless for archival, high for sharing',
    ],
    completionCriteria: 'Export completed and file downloaded',
  },
];

const WORKFLOW_ORDER: WorkspaceTab[] = [
  'dashboard',
  'scriptwriter',
  'research',
  'media',
  'video-editor',
  'analysis',
  'export',
];

export function getNextStep(currentTab: WorkspaceTab): WorkspaceTab | null {
  const idx = WORKFLOW_ORDER.indexOf(currentTab);
  if (idx === -1 || idx >= WORKFLOW_ORDER.length - 1) return null;
  return WORKFLOW_ORDER[idx + 1];
}

export function getPreviousStep(currentTab: WorkspaceTab): WorkspaceTab | null {
  const idx = WORKFLOW_ORDER.indexOf(currentTab);
  if (idx <= 0) return null;
  return WORKFLOW_ORDER[idx - 1];
}

export function getStepProgress(
  currentTab: WorkspaceTab
): { current: number; total: number } {
  const idx = WORKFLOW_ORDER.indexOf(currentTab);
  return {
    current: idx + 1,
    total: WORKFLOW_ORDER.length,
  };
}

export function getStepByTab(tab: WorkspaceTab): WorkflowStep | undefined {
  return WORKFLOW_STEPS.find((s) => s.tab === tab);
}

export function isWorkflowTab(tab: WorkspaceTab): boolean {
  return WORKFLOW_ORDER.includes(tab);
}
