export interface ExportConfig {
  format: 'mp4' | 'mov' | 'webm' | 'gif' | 'png' | 'jpg';
  resolution: '720p' | '1080p' | '4K';
  quality: 'low' | 'medium' | 'high' | 'lossless';
  frameRate: 24 | 30 | 60;
  aspectRatio: '16:9' | '9:16' | '1:1' | '4:3';
  includeAudio: boolean;
  watermark: boolean;
}

export const RESOLUTION_MAP: Record<string, { width: number; height: number }> = {
  '720p': { width: 1280, height: 720 },
  '1080p': { width: 1920, height: 1080 },
  '4K': { width: 3840, height: 2160 },
};

export const ASPECT_RATIO_MAP: Record<string, { width: number; height: number }> = {
  '16:9': { width: 1920, height: 1080 },
  '9:16': { width: 1080, height: 1920 },
  '1:1': { width: 1080, height: 1080 },
  '4:3': { width: 1440, height: 1080 },
};

export const SOCIAL_PLATFORMS = [
  {
    id: 'instagram',
    name: 'Instagram',
    icon: '📸',
    formats: ['mp4', 'jpg', 'png'],
    maxDuration: 60,
    aspectRatios: ['1:1', '4:5', '9:16'],
    shareUrl: () => `https://www.instagram.com/`,
    color: '#E4405F',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    icon: '🎵',
    formats: ['mp4'],
    maxDuration: 180,
    aspectRatios: ['9:16'],
    shareUrl: () => `https://www.tiktok.com/upload`,
    color: '#000000',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    icon: '▶️',
    formats: ['mp4', 'mov', 'webm'],
    maxDuration: 0,
    aspectRatios: ['16:9'],
    shareUrl: () => `https://studio.youtube.com/`,
    color: '#FF0000',
  },
  {
    id: 'twitter',
    name: 'X / Twitter',
    icon: '🐦',
    formats: ['mp4', 'jpg', 'png', 'gif'],
    maxDuration: 140,
    aspectRatios: ['16:9', '1:1'],
    shareUrl: () => `https://twitter.com/intent/tweet`,


    color: '#1DA1F2',
  },
];

export function generateExportFilename(
  projectName: string,
  config: ExportConfig
): string {
  const date = new Date().toISOString().split('T')[0];
  const safe = projectName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  return `${safe}_${config.resolution}_${date}.${config.format}`;
}

export function calculateEstimatedSize(config: ExportConfig, durationSeconds: number): string {
  const bitrates: Record<string, number> = {
    low: 2,
    medium: 5,
    high: 10,
    lossless: 25,
  };
  const mbps = bitrates[config.quality] || 5;
  const size = (mbps * durationSeconds) / 8;
  if (size < 1) return `${(size * 1000).toFixed(0)} KB`;
  if (size > 1000) return `${(size / 1000).toFixed(1)} GB`;
  return `${size.toFixed(0)} MB`;
}

export function getOptimalSettingsForPlatform(
  platform: string
): Partial<ExportConfig> {
  switch (platform) {
    case 'instagram':
      return { format: 'mp4', aspectRatio: '1:1', resolution: '1080p', frameRate: 30 };
    case 'tiktok':
      return { format: 'mp4', aspectRatio: '9:16', resolution: '1080p', frameRate: 60 };
    case 'youtube':
      return { format: 'mp4', aspectRatio: '16:9', resolution: '4K', frameRate: 60 };
    default:
      return {};
  }
}

export async function simulateExport(
  _config: ExportConfig,
  onProgress: (pct: number) => void
): Promise<void> {
  return new Promise((resolve) => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 15 + 5;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        onProgress(100);
        resolve();
      } else {
        onProgress(Math.min(progress, 99));
      }
    }, 400);
  });
}

export async function downloadBlob(blob: Blob, filename: string): Promise<void> {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
