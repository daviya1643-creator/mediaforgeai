type KeyHandler = (e: KeyboardEvent) => void;

const handlers: Map<string, KeyHandler[]> = new Map();

export function registerShortcut(
  combo: string,
  handler: KeyHandler,
  scope = 'global'
): () => void {
  const key = `${scope}:${combo.toLowerCase()}`;
  const existing = handlers.get(key) || [];
  existing.push(handler);
  handlers.set(key, existing);

  return () => {
    const updated = (handlers.get(key) || []).filter((h) => h !== handler);
    if (updated.length === 0) handlers.delete(key);
    else handlers.set(key, updated);
  };
}

export function initKeyboardShortcuts(): () => void {
  const listener = (e: KeyboardEvent) => {
    const ctrl = e.ctrlKey || e.metaKey;
    const shift = e.shiftKey;
    const key = e.key.toLowerCase();

    // Build combo string
    let combo = '';
    if (ctrl) combo += 'ctrl+';
    if (shift) combo += 'shift+';
    combo += key;

    // Check global and scoped handlers
    for (const [handlerKey, fns] of handlers) {
      const [scope, handlerCombo] = handlerKey.split(':');
      if (handlerCombo === combo) {
        fns.forEach((fn) => fn(e));
        if (scope === 'global') e.preventDefault();
      }
    }
  };

  window.addEventListener('keydown', listener);
  return () => window.removeEventListener('keydown', listener);
}

export const SHORTCUTS = {
  SAVE: 'ctrl+s',
  UNDO: 'ctrl+z',
  REDO: 'ctrl+shift+z',
  EXPORT: 'ctrl+e',
  NEW_PROJECT: 'ctrl+n',
  SEARCH: 'ctrl+f',
  NEXT_STEP: 'ctrl+arrowright',
  PREV_STEP: 'ctrl+arrowleft',
  TOGGLE_SIDEBAR: 'ctrl+b',
  AI_GENERATE: 'ctrl+enter',
} as const;
