interface HistoryEntry {
  timestamp: number;
  action: string;
  data: unknown;
}

let undoStack: HistoryEntry[] = [];
let redoStack: HistoryEntry[] = [];
const MAX_HISTORY = 50;

export function pushHistory(action: string, data: unknown): void {
  undoStack.push({ timestamp: Date.now(), action, data });
  if (undoStack.length > MAX_HISTORY) undoStack.shift();
  redoStack = []; // Clear redo on new action
}

export function undo(): HistoryEntry | null {
  const entry = undoStack.pop();
  if (entry) {
    redoStack.push(entry);
    return entry;
  }
  return null;
}

export function redo(): HistoryEntry | null {
  const entry = redoStack.pop();
  if (entry) {
    undoStack.push(entry);
    return entry;
  }
  return null;
}

export function getUndoCount(): number {
  return undoStack.length;
}

export function getRedoCount(): number {
  return redoStack.length;
}

export function clearHistory(): void {
  undoStack = [];
  redoStack = [];
}
